resumenNumericoPonderada <- function(){
  Library("abind")
  Library("e1071")
  Library("Hmisc")
  defaults <- list(initial.x=NULL,initial.sg=gettextRcmdr("<no variable selected>"),
                   initial.sg2=gettextRcmdr("<no variable selected>"),
                   initial.mean="1",
                   initial.sd="1", initial.se.mean="0", initial.IQR="1", initial.cv="0",
                   initial.quantiles.variable="1",
                   initial.quantiles="0, .25, .5, .75, 1",
                   initial.skewness="0", initial.kurtosis="0", initial.tab=0)

  dialog.values <- getDialog("resumenNumericoPonderada", defaults)
  initial.group <- dialog.values$initial.group
  initializeDialog(title=gettextRcmdr("Resumenes N�mericos de Variables Ponderadas"), use.tabs=TRUE, tabs=c("dataTab", "statisticsTab"))

   xBox <- variableListBox(dataTab, Numeric(), selectmode="multiple", title=gettextRcmdr("Variables (pick one or more)"),
                          initialSelection=varPosn(dialog.values$initial.x, "numeric"))

  selectVariablePonderacion <- variableComboBox(dataTab, variableList=Numeric(),
                              initialSelection=dialog.values$initial.sg, title=gettextRcmdr("Variable Ponderaci�n"))

    if (length(Factors())!=0){
     mostrar<-"readonly"
   }else {
     mostrar<-"disabled"
   }

  selectGroupComboBox <- variableComboBox(dataTab, variableList=Factors(), state=mostrar,
                    initialSelection=dialog.values$initial.sg2, title=gettextRcmdr("Variable Agrupaci�n"))



  checkBoxes(window = statisticsTab, frame="checkBoxFrame", boxes=c("mean", "sd", "se.mean", "IQR", "cv","skewness", "kurtosis"),
             initialValues=c(dialog.values$initial.mean, dialog.values$initial.sd, dialog.values$initial.se.mean, dialog.values$initial.IQR, dialog.values$initial.cv,dialog.values$initial.skewness, dialog.values$initial.kurtosis),
             labels=gettextRcmdr(c("Mean", "Standard Deviation", "Standard Error of Mean", "Interquartile Range", "Coefficient of Variation","Skewness", "Kurtosis")))

  quantilesVariable <- tclVar(dialog.values$initial.quantiles.variable)
  quantilesFrame <- tkframe(statisticsTab)
  quantilesCheckBox <- tkcheckbutton(quantilesFrame, variable=quantilesVariable,
                                     text=gettextRcmdr("Quantiles:"))
  quantiles <- tclVar(dialog.values$initial.quantiles)
  quantilesEntry <- ttkentry(quantilesFrame, width="20", textvariable=quantiles)


  onOK <- function(){
    tab <- if (as.character(tkselect(notebook)) == dataTab$ID) 0 else 1
    x <- getSelection(xBox)
    pondVar<-getSelection(selectVariablePonderacion)
    g<- getSelection(selectGroupComboBox)

    #doItAndPrint(str(sg2var))
    quants <- tclvalue(quantiles)
    meanVar <- tclvalue(meanVariable)
    sdVar <- tclvalue(sdVariable)
    se.meanVar <- tclvalue(se.meanVariable)
    IQRVar <- tclvalue(IQRVariable)
    cvVar <- tclvalue(cvVariable)
    quantsVar <- tclvalue(quantilesVariable)
    skewnessVar <- tclvalue(skewnessVariable)
    kurtosisVar <- tclvalue(kurtosisVariable)

    putDialog("resumenNumericoPonderada", list(
      initial.x=x,initial.sg=pondVar,initial.sg2=g, initial.mean=meanVar, initial.sd=sdVar, initial.se.mean=se.meanVar, initial.IQR=IQRVar, initial.cv=cvVar,
      initial.quantiles.variable=quantsVar, initial.quantiles=quants,
      initial.skewness=skewnessVar, initial.kurtosis=kurtosisVar, initial.tab=tab
    ))
    if (length(x) == 0){
      errorCondition(recall=resumenNumericoPonderada, message=gettextRcmdr("Debe seleccionar una variable."))
      return()
    }
    closeDialog()
    quants <- as.numeric( strsplit(quants,split=",")[[1]])

    posiblesstatistic<-c("mean", "sd", "se(mean)", "IQR", "quantiles", "cv", "skewness", "kurtosis")
    statselegidas<-c(meanVar, sdVar, se.meanVar, IQRVar, quantsVar, cvVar, skewnessVar, kurtosisVar)

    #print(posiblesstatistic)
    #print(statselegidas)

     stats <- posiblesstatistic[as.logical(as.numeric(statselegidas))]

    if (length(stats) == 0){
      errorCondition(recall=resumenNumericoPonderada, message=gettextRcmdr("Debe seleccionar al menos un estad�stico."))
      return()
    }

    if((NA %in% quants)||(length( quants[(quants<0)|(quants>1)])!=0)){
       errorCondition(recall=resumenNumericoPonderada, message=gettextRcmdr("Los cuantiles P tiene que ser un n?mero positivo entre 0 y 1"))
       return()
    }

     if((length(quants)==0)&&(quantsVar==1)){
       errorCondition(recall=resumenNumericoPonderada, message=gettextRcmdr("Si se selecciona la estad?stica quantil el valor del mismo no puede ser nulo"))
       return()
     }

    activeDataSet <- ActiveDataSet()
    activeDataSet<-get(activeDataSet)
    vSeleccionadas<-subset(activeDataSet,select = x)

     if(pondVar=="<ninguna variable seleccionada>"){variablePonderacion<-NULL}
    else{variablePonderacion<-activeDataSet[,pondVar]}

    if(g=="<ninguna variable seleccionada>"){factorAgrupacion<-NULL}
    else{factorAgrupacion<-activeDataSet[,g]}

##################### Imprimir la funci?n a llamar por RCommander ###########################################

    .activeDataSet<-ActiveDataSet()


    if(0 == length(x)) vponderada<-"NULL"
    else{        if (length(x) == 1){vponderada<- paste('"', x, '"', sep="")
    vponderada<-paste(.activeDataSet, "[,c(", vponderada, ")]", sep="")
    }
      else{ vponderada<-paste("c(", paste('"', x, '"', collapse=", ", sep=""), ")", sep="")

      vponderada <- paste(.activeDataSet, "[,", vponderada, "]", sep="")
      }

}
    stadisticas <- paste("c(",
                         paste(c('"mean"', '"sd"', '"se(mean)"', '"IQR"', '"quantiles"', '"cv"', '"skewness"', '"kurtosis"')
                               [c(meanVar, sdVar, se.meanVar, IQRVar, quantsVar, cvVar, skewnessVar, kurtosisVar) == 1],
                               collapse=", "), ")", sep="")




    if(pondVar=="<ninguna variable seleccionada>"){vPonderacion<-"NULL"}
    else{vPonderacion<-paste(.activeDataSet,"$",pondVar, sep="")}



    if(g=="<ninguna variable seleccionada>"){grupo<-"NULL"}
    else{grupo<-paste(.activeDataSet,"$",g, sep="")}



    if(0 == length(quants)) cuantiles <-"NULL"
    else{
      cuantiles <- if (length(quants) == 1) paste(quants , sep="")
      else paste("c(", paste(quants, collapse=",", sep=""), ")", sep="")
    }


    command<- paste("W.numSummary(data=", vponderada,", statistics =", stadisticas,", quantiles = ",cuantiles,", weights=",vPonderacion,", groups=", grupo,")",sep="" )

    print(command)

    doItAndPrint(command)







    tkfocus(CommanderWindow())
  }
  OKCancelHelp(helpSubject="W.numSummary", reset="resumenNumericoPonderada", apply ="resumenNumericoPonderada")

  tkgrid(getFrame(xBox),labelRcmdr(dataTab, text="     "),getFrame(selectVariablePonderacion),labelRcmdr(dataTab, text="     "),getFrame(selectGroupComboBox),sticky="nw")

 tkgrid(checkBoxFrame, sticky="nw")

  tkgrid(quantilesCheckBox, quantilesEntry, sticky="w")
  tkgrid(quantilesFrame)

  dialogSuffix(use.tabs=TRUE, grid.buttons=TRUE, tabs=c("dataTab", "statisticsTab"),
               tab.names=c("Data", "Statistics"))
}


W.numSummary <- function (data, statistics = c("mean", "sd", "se(mean)", "IQR","quantiles", "cv", "skewness", "kurtosis"), type = c("2","1", "3"), quantiles = c(0, 0.25, 0.5, 0.75, 1), groups=NULL, weights)
{
  #    sd <- function(x, type, ...) {
  #        apply(as.matrix(x), 2, stats::sd, na.rm = TRUE)
  #    }
  W.sd <- function(x, weights, ...) {
    sqrt(diag(cov.wt(as.matrix(x),weights,method="ML")$cov))
    #       sqrt(Hmisc::wtd.var(x,weights,normwt=FALSE,method="ML"))
  }
  #    IQR <- function(x, type, ...) {
  #        apply(as.matrix(x), 2, stats::IQR, na.rm = TRUE)
  #    }
  W.IQR <- function(x, weights, ...) {
    diff(apply(as.matrix(x), 2, Hmisc::wtd.quantile, weights, probs=c(.25,.75), type="i/n", na.rm = TRUE))
  }
  #    std.err.mean <- function(x, ...) {
  #        x <- as.matrix(x)
  #        sd <- sd(x)
  #        n <- colSums(!is.na(x))
  #        sd/sqrt(n)
  #    }
  W.std.err.mean <- function(x,weights, ...) {
    x <- as.matrix(x)
    sd <- W.sd(x,weights)
    n <- sum(weights)
    sd/sqrt(n)
  }
  #    cv <- function(x, ...) {
  #        x <- as.matrix(x)
  #        mean <- colMeans(x, na.rm = TRUE)
  #        sd <- sd(x)
  #        if (any(x <= 0, na.rm = TRUE))
  #            warning("not all values are positive")
  #        cv <- sd/mean
  #        cv[mean <= 0] <- NA
  #        cv
  #    }
  W.cv <- function(x, weights, ...) {
    x <- as.matrix(x)
    mean <- sapply(as.data.frame(x), Hmisc::wtd.mean, weights, na.rm = TRUE)
    sd <- W.sd(x,weights)
    if (any(x <= 0, na.rm = TRUE))
      warning("not all values are positive")
    W.cv <- sd/mean
    W.cv[mean <= 0] <- NA
    W.cv
  }
  #    skewness <- function(x, type, ...) {
  #        if (is.vector(x))
  #            return(e1071::skewness(x, type = type, na.rm = TRUE))
  #        apply(x, 2, skewness, type = type)
  #    }
  ## equivalente a type=1, m_3/m_2^1.5
  W.skewness <- function(x, weights, ...) {
    skew <- function(x, weights, na.rm=TRUE)
      sum(((x-wtd.mean(x, weights))^3)*weights)/sum(weights)/ W.sd(x, weights)^3
    if (is.vector(x))
      return(skew(x, weights, na.rm = TRUE))
    apply(x, 2, skew, weights=weights)
  }
  #    kurtosis <- function(x, type, ...) {
  #        if (is.vector(x))
  #            return(e1071::kurtosis(x, type = type, na.rm = TRUE))
  #        apply(x, 2, kurtosis, type = type)
  #    }
  ## equivalente a type=1, m_4/m_2^2 - 3
  W.kurtosis <- function(x, weights, ...) {
    kurt <- function(x, weights, na.rm=TRUE)
      sum(((x-Hmisc::wtd.mean(x, weights))^4)*weights)/sum(weights)/ W.sd(x, weights)^4 - 3
    if (is.vector(x))
      return(kurt(x, weights, na.rm = TRUE))
    apply(x, 2, kurt, weights, na.rm=TRUE)
  }
  data <- as.data.frame(data)
  #    if (!missing(groups)) {
  if (!missing(groups) & !is.null(groups)) {
    groups <- as.factor(groups)
    counts <- table(groups)
    if (any(counts == 0)) {
      levels <- levels(groups)
      warning("the following groups are empty: ", paste(levels[counts ==
                                                                 0], collapse = ", "))
      groups <- factor(groups, levels = levels[counts !=
                                                 0])
    }
  }
  variables <- names(data)
  if (missing(statistics))
    statistics <- c("mean", "sd", "quantiles", "IQR")
  statistics <- match.arg(statistics, c("mean", "sd", "se(mean)",
                                        "IQR", "quantiles", "cv", "skewness", "kurtosis"), several.ok = TRUE)
  type <- match.arg(type)
  type <- as.numeric(type)
  ngroups <- if (missing(groups) | is.null(groups))
    1
  else length(grps <- levels(groups))
  quantiles <- if ("quantiles" %in% statistics)
    quantiles
  else NULL
  quants <- if (length(quantiles) > 0)
    paste(100 * quantiles, "%", sep = "")
  else NULL
  nquants <- length(quants)
  stats <- c(c("mean", "sd", "se(mean)", "IQR", "cv", "skewness",
               "kurtosis")[c("mean", "sd", "se(mean)", "IQR", "cv",
                             "skewness", "kurtosis") %in% statistics], quants)
  nstats <- length(stats)
  nvars <- length(variables)


  #### chequeo de weights
  if(missing(weights) | sum(!is.na(weights))<2) {
    warning("no weights avaliable.")
    weights <- rep(1.0, dim(data)[1])
  }


  result <- list()
  if ((ngroups == 1) && (nvars == 1) && (length(statistics) ==
                                         1)) {
    if (statistics == "quantiles")
      table <- Hmisc::wtd.quantile(data[, variables], weights=weights, probs = quantiles, type="i/n", na.rm = TRUE)
    else {
      stats <- statistics
      stats[stats == "se(mean)"] <- "std.err.mean"
      stats <- switch(stats, mean="wtd.mean", sd="W.sd", IQR="W.IQR", std.err.mean="W.std.err.mean", cv="W.cv", skewness="W.skewness", kurtosis="W.kurtosis")
      table <- do.call(stats, list(x = data[, variables], weights, na.rm = TRUE))
      names(table) <- statistics
    }
    NAs <- sum(is.na(data[, variables]))
    n <- nrow(data) - NAs
    result$type <- 1
  }
  else if ((ngroups > 1) && (nvars == 1) && (length(statistics) ==
                                             1)) {
    if (statistics == "quantiles") {
      table <- matrix(unlist(tapply(data[, variables],
                                    groups, Hmisc::wtd.quantile, weights=weights, probs = quantiles, type="i/n", na.rm = TRUE)), ngroups, nquants, byrow = TRUE)
      rownames(table) <- grps
      colnames(table) <- quants
    }
    else table <- tapply(data[, variables], groups, statistics,
                         na.rm = TRUE, type = type)
    NAs <- tapply(data[, variables], groups, function(x) sum(is.na(x)))
    n <- table(groups) - NAs
    result$type <- 2
  }
  else if ((ngroups == 1)) {
    X <- as.matrix(data[, variables])
    table <- matrix(0, nvars, nstats)
    rownames(table) <- if (length(variables) > 1)
      variables
    else ""
    colnames(table) <- stats
    if ("mean" %in% stats)
      table[, "mean"] <- sapply(as.data.frame(X), Hmisc::wtd.mean, weights, na.rm = TRUE)
    #            table[, "mean"] <- colMeans(X, na.rm = TRUE)
    if ("sd" %in% stats)
      table[, "sd"] <- W.sd(X, weights)
    if ("se(mean)" %in% stats)
      table[, "se(mean)"] <- W.std.err.mean(X, weights)
    if ("IQR" %in% stats)
      table[, "IQR"] <- W.IQR(X, weights)
    if ("cv" %in% stats)
      table[, "cv"] <- W.cv(X, weights)
    if ("skewness" %in% statistics)
      table[, "skewness"] <- W.skewness(X, weights)
    if ("kurtosis" %in% statistics)
      table[, "kurtosis"] <- W.kurtosis(X, weights)
    if ("quantiles" %in% statistics) {
      #            table[, quants] <- t(apply(data[, variables, drop = FALSE], 2, quantile, probs = quantiles, na.rm = TRUE))
      table[, quants] <- t(apply(data[, variables, drop = FALSE], 2, Hmisc::wtd.quantile, probs = quantiles, weights=weights, type="i/n", na.rm = TRUE))
    }
    NAs <- colSums(is.na(data[, variables, drop = FALSE]))
    n <- nrow(data) - NAs
    result$type <- 3
  }
  else {
    data <- cbind(data,weights)                #### new
    table <- array(0, c(ngroups, nstats, nvars), dimnames = list(Group = grps,
                                                                 Statistic = stats, Variable = variables))
    NAs <- matrix(0, nvars, ngroups)
    rownames(NAs) <- variables
    colnames(NAs) <- grps
    for (variable in variables) {
      if ("mean" %in% stats)
        #                table[, "mean", variable] <- tapply(data[, variable],
        #                  groups, Hmisc::wtd.mean, weights=weights, na.rm = TRUE)
        table[, "mean", variable] <- by(data[, c(variable,"weights")],
                                        groups, function(x) Hmisc::wtd.mean(x[,1],x[,2],na.rm=TRUE) )
      if ("sd" %in% stats)
        #                table[, "sd", variable] <- tapply(data[, variable],
        #                  groups, W.sd, weights=weights, na.rm = TRUE)
        table[, "sd", variable] <- by(data[, c(variable,"weights")],
                                      groups,function(x) W.sd(x[,1],x[,2],na.rm=TRUE) )
      if ("se(mean)" %in% stats)
        #                table[, "se(mean)", variable] <- tapply(data[,
        #                  variable], groups, W.std.err.mean, weights=weights, na.rm = TRUE)
        table[, "se(mean)", variable] <- by(data[, c(variable,"weights")],
                                            groups,function(x) W.std.err.mean(x[,1],x[,2],na.rm=TRUE) )
      if ("IQR" %in% stats)
        #                table[, "IQR", variable] <- tapply(data[, variable],
        #                  groups, W.IQR, weights=weights, na.rm = TRUE)
        table[, "IQR", variable] <- by(data[, c(variable,"weights")],
                                       groups,function(x) W.IQR(x[,1],x[,2],na.rm=TRUE) )
      if ("cv" %in% stats)
        #                table[, "cv", variable] <- tapply(data[, variable],
        #                  groups, W.cv, weights=weights)
        table[, "cv", variable] <- by(data[, c(variable,"weights")],
                                      groups,function(x) W.cv(x[,1],x[,2],na.rm=TRUE) )
      if ("skewness" %in% stats)
        #                table[, "skewness", variable] <- tapply(data[,
        #                  variable], groups, W.skewness, weights=weights)
        table[, "skewness", variable] <- by(data[, c(variable,"weights")],
                                            groups,function(x) W.skewness(x[,1],x[,2],na.rm=TRUE) )
      if ("kurtosis" %in% stats)
        #                table[, "kurtosis", variable] <- tapply(data[,
        #                  variable], groups, W.kurtosis, weights=weights)
        table[, "kurtosis", variable] <- by(data[, c(variable,"weights")],
                                            groups,function(x) W.kurtosis(x[,1],x[,2],na.rm=TRUE) )
      if ("quantiles" %in% statistics) {
        res <- matrix(unlist(tapply(data[, variable],
                                    groups, wtd.quantile, weights=weights, probs = quantiles, na.rm = TRUE)), ngroups, nquants, byrow = TRUE)
        table[, quants, variable] <- res
      }
      NAs[variable, ] <- tapply(data[, variable], groups,
                                function(x) sum(is.na(x)))
    }
    if (nstats == 1)
      table <- table[, 1, ]
    if (nvars == 1)
      table <- table[, , 1]
    n <- table(groups)
    n <- matrix(n, nrow = nrow(NAs), ncol = ncol(NAs), byrow = TRUE)
    n <- n - NAs
    result$type <- 4
  }
  result$table <- table
  result$statistics <- statistics
  result$n <- n
  if (any(NAs > 0))
    result$NAs <- NAs
  class(result) <- "numSummary"
  result
}

