intervaloConfianzaVarianza <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var=gettextRcmdr("<no variable selected>"),initial.media="0",initial.valormediaconocida="",initial.nconf="0.95")
  dialog.values <- getDialog ("intervaloConfianzaVarianza", defaults)
  initializeDialog(title = gettextRcmdr("Intervalo de Confianza para la Varianza"))

  comboBoxFrame<-tkframe(top)

  selectVariableICVarianza <- variableComboBox(comboBoxFrame, variableList=Numeric(),
     initialSelection=dialog.values$initial.var, title=gettextRcmdr("Variable (Elegir una)"))


radioButtonsFrame<-tkframe(top)
  Etiqueta<-labelRcmdr(radioButtonsFrame, text="Media", foreground="blue")
  radioButtons(window = radioButtonsFrame , name="media", buttons=c("C", "D"), values=c("1", "0"),
               initialValue=dialog.values$initial.media,
               labels=gettextRcmdr(c("Conocida", "Desconocida")),

               command = function(){ if(tclvalue(mediaVariable)=="1"){
                 tk2state.set(mediaEntry, state = "normal")} else
                 { tk2state.set(mediaEntry, state = "disabled")}

                 }
               )

  mediaconocida <- tclVar(dialog.values$initial.valormediaconocida)
  mediaEntry <- ttkentry(radioButtonsFrame, width="10", textvariable=mediaconocida, state="disabled")

  nConfianzaFrame<-tkframe(top)

  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
  tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza:", foreground="blue" ),nConfianzaEntry, sticky="nw")

  onOK <- function(){

    varICVarianza<-getSelection(selectVariableICVarianza)
    activeDataSet <- ActiveDataSet()
    activeDataSet<-get(activeDataSet)

    if(varICVarianza=="<ninguna variable seleccionada>"){errorCondition(recall=intervaloConfianzaVarianza, message=gettextRcmdr("No seleccionada ninguna variable"))
      return()}
    else{activeDataSet <- ActiveDataSet()
         activeDataSet<-get(activeDataSet)
         variableICVarianza<-subset(activeDataSet,select = varICVarianza)}

    varConocida <- tclvalue(mediaVariable)
    if(varConocida=="1"){valormedia<-tclvalue(mediaconocida)
                if(is.na(as.numeric(valormedia)) || (as.numeric(valormedia)<0)) {
                  valormedia=""
                  errorCondition(recall=intervaloConfianzaVarianza, message=gettextRcmdr("Valor media conocida no es un número mayor que 0"))
                  return()
                }
                else{valormedia<-as.numeric(valormedia)}
    }else{valormedia<-""}


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=intervaloConfianzaVarianza, message=gettextRcmdr("Valor no valido para nivel de confianza, número entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}


    putDialog ("intervaloConfianzaVarianza", list(initial.var=varICVarianza,initial.media=varConocida,initial.valormediaconocida=valormedia,initial.nconf=valornConfianza))
    closeDialog()

   valormedia<-as.numeric(valormedia)
   varConocida<-as.logical(as.numeric(varConocida))

###################### Imprimir la funci?n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()

   vICVarianza<-paste(.activeDataSet,"$",varICVarianza, sep="")

  # command<- paste("calcular_ICVarianza(v.numerica=", vICVarianza,", media.conocida=", varConocida,", valor.media=", valormedia,", nivel.confianza=",valornConfianza,")",sep="" )

  # doItAndPrint(command)

   if(varConocida==FALSE){
     command2<- paste("aux<-VUM.test(",vICVarianza,", conf.level=",valornConfianza,")",sep="" )
     auxtest<-"DESCONOCIDA"
   }
   else{
     command2<- paste("aux<-VKM.test(",vICVarianza,", mu=", valormedia,", conf.level=",valornConfianza,")",sep="")
     auxtest<- paste("CONOCIDA = ", valormedia, sep="")
   }

   tipointervalo<-paste("\\nINTERVALO DE CONFIANZA PARA LA VARIANZA CON MEDIA ", auxtest,"\\n", sep="")
   linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
   tipointervalo<-paste(tipointervalo, linaux,sep="")


   command2<- paste("local({\n",command2,"\n",'aux2<-as.vector(aux[["conf.int"]]) \n',sep="")

   resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nVariable: ", varICVarianza, "\\n",'")', sep="" )
   command2<- paste(command2, resultado,"\n",sep="" )
   command2<-paste(command2,'cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")',"\n",sep="")
   command2<-paste(command2,'cat("Intervalo: (",aux2[1],",",aux2[2],")\\n")',"\n})",sep="")

   doItAndPrint(command2)


###############################################################################################################

####calcular_ICVarianza(v.numerica=variableICVarianza,media.conocida=varConocida,valor.media=valormedia, nivel.confianza=valornConfianza)

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "intervaloConfianzaVarianza", reset="intervaloConfianzaVarianza", apply="intervaloConfianzaVarianza")


  tkgrid(Etiqueta,sticky="nw" )
  tkgrid(mediaFrame , mediaEntry, sticky="nw")

  tkgrid(getFrame(selectVariableICVarianza),labelRcmdr(comboBoxFrame, text="          "),radioButtonsFrame, sticky="nw")



  tkgrid(comboBoxFrame, sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")


  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}



### Contraste de Hipotesis y Intervalo confianza para la varianza con media desconocida

VUM.test<-function (x, sigma = 1, sigmasq = sigma^2,
                    alternative = c("two.sided", "less", "greater"),
                    conf.level = 0.95, ...) {
  alternative <- match.arg(alternative)
  sigma <- sqrt(sigmasq)
  dname<-deparse(substitute(x))
  xok<-!is.na(x)
  x<-x[xok]
  n <- length(x)
  xs <- var(x)*(n-1)/sigma^2
  out <- list(statistic = c("X-squared" = xs))
  class(out) <- "htest"
  out$parameter <- c(df = n-1)
  minxs <- min(c(xs, 1/xs))
  maxxs <- max(c(xs, 1/xs))
  PVAL <- pchisq(xs, df = n - 1)

  out$p.value <- switch(alternative,
                        two.sided = 2*min(PVAL, 1 - PVAL),
                        less = PVAL,
                        greater = 1 - PVAL)
  out$conf.int <- switch(alternative,
                         two.sided = xs * sigma^2 *
                           1/c(qchisq(1-(1-conf.level)/2, df = n-1), qchisq((1-conf.level)/2, df
                                                                            = n-1)),
                         less = c(0, xs * sigma^2 /
                                    qchisq(1-conf.level, df = n-1)),
                         greater = c(xs * sigma^2 /
                                       qchisq(conf.level, df = n-1), Inf))
  attr(out$conf.int, "conf.level") <- conf.level
  out$estimate <- c("var of x" = var(x))
  out$null.value <- c(variance = sigma^2)
  out$alternative <- alternative
  out$method <- "One sample Chi-squared test for variance with unknown population mean"
  out$data.name <- dname
  names(out$estimate) <- paste("var of", out$data.name)
  return(out)
}

### Contraste de Hipotesis y Intervalo confianza para la varianza con media conocida

VKM.test<-function (x, sigma = 1, sigmasq = sigma^2,mu,
                    alternative = c("two.sided", "less", "greater"),
                    conf.level = 0.95, ...) {
  if(missing(mu)) stop("You must specify a mean of the population")
  alternative <- match.arg(alternative)
  sigma <- sqrt(sigmasq)
  dname<-deparse(substitute(x))
  xok<-!is.na(x)
  x<-x[xok]
  n <- length(x)
  x_mu<-sum((x-mu)^2)
  xs <- x_mu/sigma^2
  out <- list(statistic = c("X-squared" = xs))
  class(out) <- "htest"
  out$parameter <- c(df = n, "Mean" = mu)
  minxs <- min(c(xs, 1/xs))
  maxxs <- max(c(xs, 1/xs))
  PVAL <- pchisq(xs, df = n)

  out$p.value <- switch(alternative,
                        two.sided = 2*min(PVAL, 1 - PVAL),
                        less = PVAL,
                        greater = 1 - PVAL)
  out$conf.int <- switch(alternative,
                         two.sided = xs * sigma^2 *
                           1/c(qchisq(1-(1-conf.level)/2, df = n), qchisq((1-conf.level)/2, df
                                                                          = n)),
                         less = c(0, xs * sigma^2 /
                                    qchisq(1-conf.level, df = n)),
                         greater = c(xs * sigma^2 /
                                       qchisq(conf.level, df = n), Inf))
  attr(out$conf.int, "conf.level") <- conf.level
  out$estimate <- c("var of x" = var(x))
  out$null.value <- c(variance = sigma^2)
  out$alternative <- alternative
  out$method <- "One sample Chi-squared test for variance with known population mean"
  out$data.name <- dname
  names(out$estimate) <- paste("var of", out$data.name)
  return(out)
}
