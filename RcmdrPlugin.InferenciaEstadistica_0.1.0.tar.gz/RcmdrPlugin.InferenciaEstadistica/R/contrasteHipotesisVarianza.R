contrasteHipotesisVarianza <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var=gettextRcmdr("<no variable selected>"),initial.Media="0",initial.valorMediaconocida="",
                    initial.nconf="0.95",initial.alternative = "two.sided",initial.sigma2 = "0.0")

  dialog.values <- getDialog ("contrasteHipotesisVarianza", defaults)
  initializeDialog(title = gettextRcmdr("Contraste de Hip�tesis para la Varianza"))

  comboBoxFrame<-tkframe(top)

  selectVariableHVarianzaC <- variableComboBox(comboBoxFrame, variableList=Numeric(),
     initialSelection=dialog.values$initial.var, title=gettextRcmdr("Variable (Elegir una)"))


radioButtonsFrame<-tkframe(top)
  Etiqueta<-labelRcmdr(radioButtonsFrame, text="Media", foreground="blue")
  radioButtons(window = radioButtonsFrame , name="Media", buttons=c("C", "D"), values=c("1", "0"),
               initialValue=dialog.values$initial.Media,
               labels=gettextRcmdr(c("Conocida", "Desconocida")),

               command = function(){ if(tclvalue(MediaVariable)=="1"){
                 tk2state.set(MediaEntry, state = "normal")} else
                 { tk2state.set(MediaEntry, state = "disabled")}

                 }
               )

  Mediaconocida <- tclVar(dialog.values$initial.valorMediaconocida)
  MediaEntry <- ttkentry(radioButtonsFrame, width="10", textvariable=Mediaconocida, state="disabled")


  optionsFrame <- tkframe(top)
  radioButtons(optionsFrame, name = "alternative", buttons = c("twosided",
                                                               "less", "greater"), values = c("two.sided", "less", "greater"),
               labels = gettextRcmdr(c("Varianza Poblacional != sigma^2_0", "Varianza Poblacional < sigma^2_0",
                                       "Varianza Poblacional > sigma^2_0")), title = gettextRcmdr("Alternative Hypothesis"),
               initialValue = dialog.values$initial.alternative)





  rightFrame<-tkframe(top)

  sigma2Frame <- tkframe(rightFrame)
  sigma2Variable <- tclVar(dialog.values$initial.sigma2)
  sigma2Field <- ttkentry(sigma2Frame, width = "5", textvariable = sigma2Variable)
  tkgrid(labelRcmdr(sigma2Frame, text="Hip�tesis Nula: sigma^2 = ", foreground="blue" ), sigma2Field, sticky="nw")

  nConfianzaFrame<-tkframe(rightFrame)
  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
 # tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza = ", foreground="blue" ),nConfianzaEntry, sticky="nw")




  onOK <- function(){

    varHVarianzaC<-getSelection(selectVariableHVarianzaC)
    activeDataSet <- ActiveDataSet()
    activeDataSet<-get(activeDataSet)

    if(varHVarianzaC=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesisVarianza, message=gettextRcmdr("No seleccionada ninguna variable"))
      return()}
    else{activeDataSet <- ActiveDataSet()
         activeDataSet<-get(activeDataSet)
         variableHVarianzaC<-subset(activeDataSet,select=varHVarianzaC)}

    varConocida <- tclvalue(MediaVariable)
    if(varConocida=="1"){valorMedia<-tclvalue(Mediaconocida)
                if(is.na(as.numeric(valorMedia)) || (as.numeric(valorMedia)<0)) {
                  valorMedia=""
                  errorCondition(recall=contrasteHipotesisVarianza, message=gettextRcmdr("Valor Media conocida no es un n�mero mayor que 0"))
                  return()
                }
                else{valorMedia<-as.numeric(valorMedia)}
    }else{valorMedia<-""}


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=contrasteHipotesisVarianza, message=gettextRcmdr("Valor no v�lido para nivel de confianza, n�mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}

    valorsigma20<-tclvalue(sigma2Variable)

    if(is.na(as.numeric(valorsigma20))||(as.numeric(valorsigma20)<0)){
      valorsigma20="0.0"
      errorCondition(recall=contrasteHipotesisVarianza, message=gettextRcmdr("Valor no v�lido para la Hip�tesis Nula sigma^2, n�mero positivo"))
      return()
    }
    else{ valorsigma20<-as.numeric(valorsigma20)}

    varHAlternativa<-tclvalue(alternativeVariable)

    putDialog ("contrasteHipotesisVarianza", list(initial.var=varHVarianzaC,initial.Media=varConocida,initial.valorMediaconocida=valorMedia,initial.nconf=valornConfianza,
                  initial.alternative = varHAlternativa,initial.sigma2 = valorsigma20))
    closeDialog()

   valorMedia<-as.numeric(valorMedia)
   varConocida<-as.logical(as.numeric(varConocida))


   ###################### Imprimir la funci?n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()

   vHCVarianza<-paste(.activeDataSet,"$",varHVarianzaC, sep="")

   Haltern<-paste('"',varHAlternativa,'"',sep="")

  # command<- paste("calcular_CHVarianza(v.numerica=", vHCVarianza,", media.conocida=", varConocida,", valor.media=", valorMedia,", hipotesis.alternativa=",Haltern,", sigma20=",valorsigma20, ", nivel.confianza=",valornConfianza,")",sep="" )


   if(varConocida==FALSE){
     command2<- paste("aux<-VUM.test(",vHCVarianza,", alternative=",Haltern,", sigma=",sqrt(valorsigma20),", conf.level=",valornConfianza,")",sep="" )
     auxtest<-"DESCONOCIDA"
   }
   else{
     command2<- paste("aux<-VKM.test(",vHCVarianza,", alternative=",Haltern,", sigma=",sqrt(valorsigma20),", mu=", valorMedia,", conf.level=",valornConfianza,")",sep="")
     auxtest<- paste("CONOCIDA = ", valorMedia, sep="")
   }

   tipointervalo<-paste("\\nCONTRASTE DE HIP�TESIS PARA LA VARIANZA CON MEDIA ", auxtest,"\\n", sep="")
   linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
   tipointervalo<-paste(tipointervalo, linaux,sep="")
   command2<- paste("local({\n",command2,"\n",sep="")

   resultado<-paste('cat("',tipointervalo, "\\nVariable: ", varHVarianzaC, "\\n",'")', sep="" )
   #distribucion<-'\n if(names(aux$statistic)=="z"){cat("Distribuci�n:",names(aux$statistic),"con distribuci�n N(0,1)\\n")}
   #                    else {cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter),"grados de libertad\\n")}'

   distribucion<-'\n cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter[1]),"grados de libertad\\n")'
   e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'

   p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
   if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
   if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
   if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}'


   if (varHAlternativa == "two.sided"){h.alt<-paste("Varianza poblacional no es igual a Hip�tesis Nula = ",valorsigma20,sep="")}
   if (varHAlternativa == "less"){h.alt<-paste("Varianza poblacional es menor a Hip�tesis Nula = ",valorsigma20,sep="")}
   if (varHAlternativa == "greater"){h.alt<- paste("Varianza poblacional es mayor a Hip�tesis Nula = ",valorsigma20,sep="")}
   h.alt<-paste('\n cat("Hip�tesis Alternativa:","',h.alt,'","\\n")')

   e.muestral<-'\n cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")'


   command2<- paste(command2, resultado, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

   doItAndPrint(command2)

   ###############################################################################################################

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "intervaloConfianzaVarianza", reset="contrasteHipotesisVarianza", apply="contrasteHipotesisVarianza")


  tkgrid(Etiqueta,sticky="nw" )
  tkgrid(MediaFrame , MediaEntry, sticky="nw")

  tkgrid(getFrame(selectVariableHVarianzaC),labelRcmdr(comboBoxFrame, text="                 "),radioButtonsFrame, sticky="nw")
  tkgrid(comboBoxFrame, sticky="nw")

  tkgrid(labelRcmdr(top, text="          "),sticky="nw")

  tkgrid(labelRcmdr(rightFrame, text="        "),sticky="nw")
  tkgrid(sigma2Frame,sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")


  tkgrid(alternativeFrame,labelRcmdr(optionsFrame, text="          "),rightFrame, sticky="nw")
  tkgrid(optionsFrame,sticky="nw")

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}



