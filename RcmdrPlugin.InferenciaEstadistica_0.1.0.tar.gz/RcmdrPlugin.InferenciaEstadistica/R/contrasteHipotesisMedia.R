contrasteHipotesisMedia <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var=gettextRcmdr("<no variable selected>"),initial.varianza="0",initial.valorvarianzaconocida="",
                    initial.nconf="0.95",initial.alternative = "two.sided",initial.mu = "0.0")

  dialog.values <- getDialog ("contrasteHipotesisMedia", defaults)
  initializeDialog(title = gettextRcmdr("Contraste de Hip�tesis para la Media"))

  comboBoxFrame<-tkframe(top)

  selectVariableHCMedia <- variableComboBox(comboBoxFrame, variableList=Numeric(),
     initialSelection=dialog.values$initial.var, title=gettextRcmdr("Variable (Elegir una)"))


radioButtonsFrame<-tkframe(top)
  Etiqueta<-labelRcmdr(radioButtonsFrame, text="Varianza", foreground="blue")
  radioButtons(window = radioButtonsFrame , name="varianza", buttons=c("C", "D"), values=c("1", "0"),
               initialValue=dialog.values$initial.varianza,
               labels=gettextRcmdr(c("Conocida", "Desconocida")),

               command = function(){ if(tclvalue(varianzaVariable)=="1"){
                 tk2state.set(varianzaEntry, state = "normal")} else
                 { tk2state.set(varianzaEntry, state = "disabled")}

                 }
               )

  varianzaconocida <- tclVar(dialog.values$initial.valorvarianzaconocida)
  varianzaEntry <- ttkentry(radioButtonsFrame, width="10", textvariable=varianzaconocida, state="disabled")


  optionsFrame <- tkframe(top)
  radioButtons(optionsFrame, name = "alternative", buttons = c("twosided",
                                                               "less", "greater"), values = c("two.sided", "less", "greater"),
               labels = gettextRcmdr(c("Population mean != mu0", "Population mean < mu0",
                                       "Population mean > mu0")), title = gettextRcmdr("Alternative Hypothesis"),
               initialValue = dialog.values$initial.alternative)





  rightFrame<-tkframe(top)

  muFrame <- tkframe(rightFrame)
  muVariable <- tclVar(dialog.values$initial.mu)
  muField <- ttkentry(muFrame, width = "5", textvariable = muVariable)
  tkgrid(labelRcmdr(muFrame, text="Hip�tesis Nula: mu = ", foreground="blue" ), muField, sticky="nw")

  nConfianzaFrame<-tkframe(rightFrame)
  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
 # tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza = ", foreground="blue" ),nConfianzaEntry, sticky="nw")




  onOK <- function(){

    varHCMedia<-getSelection(selectVariableHCMedia)
    activeDataSet <- ActiveDataSet()
    activeDataSet<-get(activeDataSet)

    if(varHCMedia=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesisMedia, message=gettextRcmdr("No seleccionada ninguna variable"))
      return()}
    else{activeDataSet <- ActiveDataSet()
         activeDataSet<-get(activeDataSet)
         variableHCMedia<-subset(activeDataSet,select=varHCMedia)}

    varConocida <- tclvalue(varianzaVariable)
    if(varConocida=="1"){valorvarianza<-tclvalue(varianzaconocida)
                if(is.na(as.numeric(valorvarianza)) || (as.numeric(valorvarianza)<0)) {
                  valorvarianza=""
                  errorCondition(recall=contrasteHipotesisMedia, message=gettextRcmdr("Valor varianza conocida no es un número mayor que 0"))
                  return()
                }
                else{valorvarianza<-as.numeric(valorvarianza)}
    }else{valorvarianza<-""}


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=contrasteHipotesisMedia, message=gettextRcmdr("Valor no valido para nivel de confianza, número entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}

    valormu0<-tclvalue(muVariable)

    if(is.na(as.numeric(valormu0))){
      valormu0="0.0"
      errorCondition(recall=contrasteHipotesisMedia, message=gettextRcmdr("Valor no valido para la Hip?tesis Nula mu0"))
      return()
    }
    else{ valormu0<-as.numeric(valormu0)}

    varHAlternativa<-tclvalue(alternativeVariable)

    putDialog ("contrasteHipotesisMedia", list(initial.var=varHCMedia,initial.varianza=varConocida,initial.valorvarianzaconocida=valorvarianza,initial.nconf=valornConfianza,
                  initial.alternative = varHAlternativa,initial.mu = valormu0))
    closeDialog()

   valorvarianza<-as.numeric(valorvarianza)
   varConocida<-as.logical(as.numeric(varConocida))

###################### Imprimir la funci?n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()

   vHCMedia<-paste(.activeDataSet,"$",varHCMedia, sep="")

   Haltern<-paste('"',varHAlternativa,'"',sep="")

#   command<- paste("calcular_CHMedia(v.numerica=", vHCMedia,", varianza.conocida=", varConocida,", valor.varianza=", valorvarianza,", hipotesis.alternativa=",Haltern,", mu0=",valormu0, ", nivel.confianza=",valornConfianza,")",sep="" )

#   doItAndPrint(command)



   if(varConocida==FALSE){
     command2<- paste("aux<-t.test(",vHCMedia,", alternative=",Haltern,", mu=",valormu0,", conf.level=",valornConfianza,")",sep="" )
     auxtest<-"DESCONOCIDA"
   }
   else{
     command2<- paste("aux<-MKV.test(",vHCMedia,", stdev=", sqrt(valorvarianza),", alternative=",Haltern,", mu=",valormu0,", conf.level=",valornConfianza,")",sep="")
     auxtest<- paste("CONOCIDA = ", valorvarianza, sep="")
   }

   tipointervalo<-paste("\\nCONTRASTE DE HIP�TESIS PARA LA MEDIA CON VARIANZA ", auxtest,"\\n", sep="")
   linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
   tipointervalo<-paste(tipointervalo, linaux,sep="")
   command2<- paste("local({\n",command2,"\n",sep="")

   resultado<-paste('cat("',tipointervalo, "\\nVariable: ", varHCMedia, "\\n",'")', sep="" )
   distribucion<-'\n if(names(aux$statistic)=="z"){cat("Distribuci�n:",names(aux$statistic),"con distribuci�n N(0,1)\\n")}
   else {cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter),"grados de libertad\\n")}'

   #distribucion<-'\n cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter),"grados de libertad\\n")'
   e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'

   p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
   if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
   if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
   if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}'


   if (varHAlternativa == "two.sided"){h.alt<-paste("Media poblacional no es igual a Hip�tesis Nula = ",valormu0,sep="")}
   if (varHAlternativa == "less"){h.alt<-paste("Media poblacional es menor a Hip�tesis Nula = ",valormu0,sep="")}
   if (varHAlternativa == "greater"){h.alt<- paste("Media poblacional es mayor a Hip�tesis Nula = ",valormu0,sep="")}
   h.alt<-paste('\n cat("Hip�tesis Alternativa:","',h.alt,'","\\n")')

   e.muestral<-'\n cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")'

   command2<- paste(command2, resultado, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

   doItAndPrint(command2)

###############################################################################################################


   ###  calcular_CHMedia(v.numerica=variableHCMedia,varianza.conocida=varConocida,valor.varianza=valorvarianza, hipotesis.alternativa=varHAlternativa,mu0=valormu0,nivel.confianza=valornConfianza)

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "intervaloConfianzaMedia", reset="contrasteHipotesisMedia", apply="contrasteHipotesisMedia")


  tkgrid(Etiqueta,sticky="nw" )
  tkgrid(varianzaFrame , varianzaEntry, sticky="nw")

  tkgrid(getFrame(selectVariableHCMedia),labelRcmdr(comboBoxFrame, text="                 "),radioButtonsFrame, sticky="nw")
  tkgrid(comboBoxFrame, sticky="nw")

  tkgrid(labelRcmdr(top, text="          "),sticky="nw")

  tkgrid(labelRcmdr(rightFrame, text="        "),sticky="nw")
  tkgrid(muFrame,sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")

  tkgrid(alternativeFrame,labelRcmdr(optionsFrame, text="          "),rightFrame, sticky="nw")
  tkgrid(optionsFrame,sticky="nw")


  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}



