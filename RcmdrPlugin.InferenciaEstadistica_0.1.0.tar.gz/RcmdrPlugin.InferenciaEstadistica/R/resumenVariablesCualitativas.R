resumenVariablesCualitativas <- function () {
  #Library("abind")
  #Library("e1071")

  defaults <- list (initial.var1=NULL, initial.var2=NULL, initial.ordenadofrecuenciaVar="0", initial.cuantil=0.5)
  dialog.values <- getDialog ("resumenVariablesCualitativas", defaults)
  initializeDialog(title = gettextRcmdr("Resumen Variables Cualitativas"))


  #Instrucciones para hallar las variables cualitativas ordinal - unicamente factors() eliminando vectores de char
  activeDataSet<-ActiveDataSet()
  activeDataSet<-get(activeDataSet)
  factores_en_ActiveDataSet<-Factors()
  datos_tipo_string<-names(activeDataSet[factores_en_ActiveDataSet])[(sapply(activeDataSet[factores_en_ActiveDataSet], is.character))]
  factores_en_ActiveDataSet<-factores_en_ActiveDataSet[!factores_en_ActiveDataSet %in% datos_tipo_string]


  #Construyo los diferentes Box existentes

  variablesFrame<-tkframe(top)
  #nonumeric<-Variables()[!Variables()%in%Numeric()]
  vcualitativas <- variableListBox(variablesFrame, Factors(), selectmode="multiple", title = gettextRcmdr("Variables cualitativas (No num�rica) "),
                                       initialSelection = varPosn(dialog.values$initial.var1,"factor"))
  vcualitativaordinal <- variableListBox(variablesFrame, factores_en_ActiveDataSet , selectmode="multiple", title = gettextRcmdr("Variables cualitativas (Ordinal)"),
                                 initialSelection = varPosn(dialog.values$initial.var2,"all"))
  skFrame <- tkframe(top)
  ordenadofrecuenciaVar<-tclVar(dialog.values$initial.ordenadofrecuenciaVar)
  ordenadofrecuenciaCheckBox<-ttkcheckbutton(skFrame, variable=ordenadofrecuenciaVar,text=gettextRcmdr("Ordenado por Frecuencia"))

  cuantilFrame<-tkframe(top)

  cuantilVar<-tclVar(dialog.values$initial.cuantil)
  cuantilEntry<-ttkentry(cuantilFrame,width="5",textvariable=cuantilVar)
  tkgrid(labelRcmdr(cuantilFrame, text="Cuantil-P:"),cuantilEntry, sticky="nw")

  onOK <- function() {

    var1<-getSelection(vcualitativas)
    var2<-getSelection(vcualitativaordinal)
    var3<-tclvalue(ordenadofrecuenciaVar)
    var4<-tclvalue(cuantilVar)

    #Se verifica que como minimo hay una variable seleccionada

    if ((0 == length(var1)) && (0 == length(var2))){
      errorCondition(recall = resumenVariablesCualitativas, message = gettextRcmdr("Debe seleccionar como m�nimo una Variable"))
      return()
    }

    #Se verifica que el Percentil elegido es valido

    if ((var4!="") && ((var4<0)||(var4>1))){
      errorCondition(recall = resumenVariablesCualitativas, message = gettextRcmdr("Cuantil P no v�lido - Valor 0 y 1"))
      return()
    }

    putDialog ("resumenVariablesCualitativas", list(initial.var1=var1, initial.var2=var2, initial.ordenadofrecuenciaVar=var3,initial.cuantil=var4))
    closeDialog()


    vCualitativaNoNumerica<-subset(activeDataSet,select = var1)
    vCualitativaOrdinal<-subset(activeDataSet,select = var2)
    ordenado_Frecuencia<-as.logical(as.numeric(var3))
    cuantilP<-var4

###################### Imprimir la funci?n a llamar por RCommander ###########################################

    .activeDataSet<-ActiveDataSet()

    if(0 == length(var1)) vnominal<-"NULL"
    else{        if (length(var1) == 1){vnominal<- paste('"', var1, '"', sep="")
                                 vnominal<-paste(.activeDataSet, "[", vnominal, "]", sep="")
                                 }
                 else{ vnominal<-paste("c(", paste('"', var1, '"', collapse=", ", sep=""), ")", sep="")

                       vnominal <- paste(.activeDataSet, "[,", vnominal, "]", sep="")
                      }
    }

    if(0 == length(var2)) vordinal<-"NULL"
    else{           if (length(var2) == 1){vordinal<- paste('"', var2, '"', sep="")
                                          vordinal<-paste(.activeDataSet, "[", vordinal, "]", sep="")
                    }
                   else{ vordinal<-paste("c(", paste('"', var2, '"', collapse=", ", sep=""), ")", sep="")
                         vordinal <- paste(.activeDataSet, "[,", vordinal, "]", sep="")
                     }
    }


    command<-paste("calcular_frecuencia(df.nominal=", vnominal,", ordenado.frec=",ordenado_Frecuencia ,", df.ordinal=",vordinal,", cuantil.p=",cuantilP,", iprint = TRUE)", sep="")
    doItAndPrint(command)

############M�todo de funcionamiento inicial No muestra resultados en RCommander #############################
        ### calcular_frecuencia(df.nominal=vCualitativaNoNumerica,ordenado.frec=ordenado_Frecuencia, df.ordinal=vCualitativaOrdinal, cuantil.p=cuantilP, iprint = TRUE)


     tkfocus(CommanderWindow())
  }

 # OKCancelHelp(helpSubject = "calcular_frecuencia", reset="resumenVariablesCualitativas", apply="resumenVariablesCualitativas")
  OKCancelHelp(helpSubject = "calcular_frecuencia", reset="resumenVariablesCualitativas")


  tkgrid(getFrame(vcualitativas),labelRcmdr(variablesFrame,text="   "), getFrame(vcualitativaordinal),sticky="nw")
  tkgrid(variablesFrame,sticky="w")
  tkgrid(labelRcmdr(top,text=" "))

  tkgrid(ordenadofrecuenciaCheckBox,labelRcmdr(skFrame,text="               "),cuantilFrame, sticky="w")
  tkgrid(skFrame, sticky="nw")

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}




### menu: 01 Resumenes numercios - v. cualitativa
calcular_frecuencia <- function(df.nominal, ordenado.frec=FALSE, df.ordinal, cuantil.p=0.5, iprint=TRUE,...)
{
  tabla.frec <- list(.nominal=NULL,.ordinal=NULL,df.cuantil=NULL)
  if (!is.null(df.nominal)) {
    tabla.frec$.nominal <- lapply(df.nominal,tabla.frec.cualitativa, ordenado.frec=ordenado.frec)
    if(iprint) {
      cat("\n-------------------------------\n")
      cat("\nVariables Nominales:\n")
      lapply(1:length(tabla.frec$.nominal), pprint, Table=tabla.frec$.nominal)
    }
  }
  if (!is.null(df.ordinal)) {     # ordeado polos factores
    tabla.frec$.ordinal <- lapply(df.ordinal,tabla.frec.cualitativa, ordinal=TRUE)
    cuantil <- sapply(1:length(tabla.frec$.ordinal), function(x,cuantil.p) tabla.frec$.ordinal[[x]][,"Fi"][ !(tabla.frec$.ordinal[[x]][,"Fi"] < cuantil.p) ][1], cuantil.p=cuantil.p)

    if(iprint) {
      cat("\n-------------------------------\n")
      cat("\nVariables Ordinales:\n")
      lapply(1:(length(tabla.frec$.ordinal)), pprint, Table=tabla.frec$.ordinal)
      cat("\nCuantil: ",cuantil.p, "\n")
      tabla.frec$df.cuantil <- data.frame(Variable=names(cuantil), Ni=cuantil)
      row.names(tabla.frec$df.cuantil) <- names(df.nominal)
      print(tabla.frec$df.cuantil, 3)  }
  }
  return( invisible(tabla.frec))
}


###

tabla.frec.cualitativa <- function(v.factor, ordenado.frec=FALSE, na.rm=FALSE, ordinal=FALSE, ...)
{
  .Table <- table(v.factor, useNA= if(na.rm) "always" else "no")
  N <- sum(.Table)
  if(!ordinal) {
    .Frec <- cbind(ni=.Table,fi=.Table/N)
    if(ordenado.frec) {
      return(.Frec[order(.Frec[,1],decreasing=TRUE),])
    } else  return(.Frec)
  } else {
    .Frec <- cbind(ni=.Table,fi=.Table/N, Ni= Ni<- cumsum(.Table), Fi=Ni/N)
    return(.Frec)
  }
}

pprint <- function(x,Table) {
  cat("\n Variable: ",names(Table)[x],"\n")
  print(Table[[x]], digits=3)
  cat("N= ",sum(Table[[x]][,1]),"\n")
}


