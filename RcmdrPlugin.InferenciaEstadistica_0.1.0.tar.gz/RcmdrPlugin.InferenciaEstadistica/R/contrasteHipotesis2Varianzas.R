contrasteHipotesis2Varianzas <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var="<ninguna variable seleccionada>",initial.nconf="0.95",initial.alternative = "two.sided",initial.sigma = "1")
  dialog.values <- getDialog ("contrasteHipotesis2Varianzas", defaults)
  initializeDialog(title = gettextRcmdr("Contraste de Hip�tesis para Cociente Varianzas"))

##Creaci�n de los ComboBox

  selectFactorsFrame<-tkframe(top)
  comboBoxFrame<-tkframe(selectFactorsFrame)

  twoOrMoreLevelFactors<-twoOrMoreLevelFactors() ##NULL SI NO ACTIVEDATASET

  if (length(twoOrMoreLevelFactors())!=0){
    mostrar<-"readonly"
  }else {
    mostrar<-"disabled"
  }


  valuescombo_box<-c("<ninguna variable seleccionada>",twoOrMoreLevelFactors())
  varcombo_box=tclVar(valuescombo_box[1])

  combo_box<-ttkcombobox(comboBoxFrame,values=valuescombo_box,textvariable=varcombo_box,state=mostrar)
  tkgrid(labelRcmdr(comboBoxFrame, text="Grupos (Elegir uno)", foreground="blue" ), sticky="nw")
  tkgrid(combo_box,sticky="nw")


  tkbind(combo_box, "<<ComboboxSelected>>",function(){

    value<-tclvalue(varcombo_box)
    if(value!="<ninguna variable seleccionada>"){
      datasetactivo <- ActiveDataSet()
      datasetactivo<-get(datasetactivo)
      niveles<-levels(datasetactivo[,value])
      tkconfigure(combo_box2,values=niveles)
      tclvalue(varcombo_box2)<-niveles[1]
      tk2state.set(combo_box2, state="readonly")
      tkconfigure(combo_box3,values=niveles)
      tclvalue(varcombo_box3)<-niveles[2]
      tk2state.set(combo_box3, state="readonly")
      tkfocus(combo_box2)}
    else{tk2state.set(combo_box2, state="disabled")
         niveles<-"<ninguna variable seleccionada>"
          tkconfigure(combo_box2,values=niveles)
          tclvalue(varcombo_box2)<-niveles
          tkconfigure(combo_box3,values=niveles)
          tclvalue(varcombo_box3)<-niveles}})

  varcombo_box2=tclVar("<ninguna variable seleccionada>")
  combo_box2<-ttkcombobox(comboBoxFrame,values=varcombo_box2,textvariable=varcombo_box2,state="disabled")

  tkgrid(labelRcmdr(comboBoxFrame, text="Grupo 1", foreground="blue" ), sticky="nw")
  tkgrid(combo_box2, sticky="nw")

  varcombo_box3=tclVar("<ninguna variable seleccionada>")
  combo_box3<-ttkcombobox(comboBoxFrame,values=varcombo_box3,textvariable=varcombo_box3,state="disabled")

  tkgrid(labelRcmdr(comboBoxFrame, text="Grupo 2", foreground="blue" ), sticky="nw")
  tkgrid(combo_box3, sticky="nw")

##Fin creaci�n comboBox

  variablenumericaFrame<-tkframe(top)
  selectVariableICMedia <- variableComboBox(variablenumericaFrame, variableList=Numeric(),
  initialSelection=dialog.values$initial.var, title=gettextRcmdr("Variable (Elegir una)"))
  tkgrid(getFrame(selectVariableICMedia), sticky="nw")


  #### Inicio Contraste Hipotesis Alternativa, Nula y Nivel Confianza (Frame)

  optionsFrame <- tkframe(top)
  radioButtons(optionsFrame, name = "alternative", buttons = c("twosided",
                                                               "less", "greater"), values = c("two.sided", "less", "greater"),
               labels = gettextRcmdr(c("Cociente Poblacional != sigma_1 / sigma_2", "Cociente Poblacional < sigma_1 / sigma_2",
                                       "Cociente Poblacional > sigma_1 / sigma_2")), title = gettextRcmdr("Alternative Hypothesis"),
               initialValue = dialog.values$initial.alternative)


  rightFrame<-tkframe(top)

  sigmaFrame <- tkframe(rightFrame)
  sigmaVariable <- tclVar(dialog.values$initial.sigma)
  sigmaField <- ttkentry(sigmaFrame, width = "5", textvariable = sigmaVariable)
  tkgrid(labelRcmdr(sigmaFrame, text="Hip�tesis Nula: sigma1 / sigma2 = ", foreground="blue" ), sigmaField, sticky="nw")

  nConfianzaFrame<-tkframe(rightFrame)
  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
 # tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza (1-alpha)= ", foreground="blue" ),nConfianzaEntry, sticky="nw")

  #######################################

  onOK <- function(){

    grupoICVarianzas<-tclvalue(varcombo_box)
    if(grupoICVarianzas=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesis2Varianzas, message=gettextRcmdr("No seleccionada ning�n Grupo"))
      return()}
    if ((length(twoOrMoreLevelFactors)!=0)&&(grupoICVarianzas !="<ninguna variable seleccionada>")){
      varGrupo1<-tclvalue(varcombo_box2)
      varGrupo2<-tclvalue(varcombo_box3)}
    else {
      variableICProporcion<-NULL
      varGrupo1<-NULL
      varGrupo2<-NULL
    }


    varICVarianzas<-getSelection(selectVariableICMedia)
    if(varICVarianzas=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesis2Varianzas, message=gettextRcmdr("No seleccionada ninguna variable"))
      return()}

    if(varGrupo1==varGrupo2){errorCondition(recall=contrasteHipotesis2Varianzas, message=gettextRcmdr("Grupo 1 y 2 no pueden tener seleccionado el mismo valor"))
      return()}


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=contrasteHipotesis2Varianzas, message=gettextRcmdr("Valor no valido para nivel de confianza, n�mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}

    valorsigma0<-tclvalue(sigmaVariable)

    if(is.na(as.numeric(valorsigma0))||(as.numeric(valorsigma0)<=0)){
      valorsigma0="0.0"
      errorCondition(recall=contrasteHipotesis2Varianzas, message=gettextRcmdr("Valor no v�lido para la Hip�tesis Nula"))
      return()
    }
    else{ valorsigma0<-as.numeric(valorsigma0)}

    varHAlternativa<-tclvalue(alternativeVariable)


    putDialog ("contrasteHipotesis2Varianzas", list(initial.var=varICVarianzas,initial.nconf=valornConfianza,initial.alternative = varHAlternativa,initial.sigma = valorsigma0))
    closeDialog()


###################### Imprimir la funci�n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()
    level1<-tclvalue(varcombo_box2)
    level2<-tclvalue(varcombo_box3)

     vICGrupos<-paste(.activeDataSet,"$",grupoICVarianzas, sep="")

    vLevelGrupos<-paste("c(",'"',tclvalue(varcombo_box2),'"',",",'"',tclvalue(varcombo_box3),'"',")",sep="")

    vVariable<-paste(.activeDataSet,"$",varICVarianzas, sep="")

    Haltern<-paste('"',varHAlternativa,'"',sep="")


 # command<- paste("calcular_HC2Varianzas(grupo =", vICGrupos,", levels.grupo =", vLevelGrupos,", variable =", vVariable,", hipotesis.alternativa=",Haltern,", hipotesis.nula=",valorsigma0,", nivel.confianza=",valornConfianza,")",sep="" )
 #  doItAndPrint(command)

    command2<- paste("local({\n","var1<-subset(",.activeDataSet,",", grupoICVarianzas,"==",'"',level1,'"',", select=",varICVarianzas,")",sep="")
    command2<- paste(command2,"\n","var2<-subset(",.activeDataSet,",", grupoICVarianzas,"==",'"',level2,'"',", select=",varICVarianzas,")",sep="")

    command2<-paste(command2,"\n","aux<-var.test(var1[,1], var2[,1]",", ratio=",valorsigma0,", alternative=",Haltern ,", conf.level=",valornConfianza,")\n",sep="")

    tipointervalo<-"\\nCONTRASTE DE HIP�TESIS PARA EL COCIENTE DE VARIANZAS \\n"
    linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
    tipointervalo<-paste(tipointervalo, linaux,sep="")

    resultado<-paste('cat("',tipointervalo, "\\nVariable: ", varICVarianzas,"\\nGrupos: ",grupoICVarianzas," [",level1," vs. ", level2 ,"]\\n",'")', sep="" )

    distribucion<-'\n cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter[1]),"y", as.numeric(aux$parameter[2]),"grados de libertad\\n")'
    e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'

    p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
    if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
    if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
    if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}\n'


    if (varHAlternativa == "two.sided"){h.alt<-paste("Cociente Real no es igual a Hip�tesis Nula = ",valorsigma0,sep="")}
    if (varHAlternativa == "less"){h.alt<-paste("Cociente Real es menor a Hip�tesis Nula = ",valorsigma0,sep="")}
    if (varHAlternativa == "greater"){h.alt<- paste("Cociente Real es mayor a Hip�tesis Nula = ",valorsigma0,sep="")}
    h.alt<-paste('\n cat("Hip�tesis Alternativa:","',h.alt,'","\\n")')

    e.muestral<-'\n cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")'
    command2<- paste(command2, resultado, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

    doItAndPrint(command2)

    ###############################################################################################################

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "var.test", reset="contrasteHipotesis2Varianzas", apply="contrasteHipotesis2Varianzas")

  tkgrid(comboBoxFrame,labelRcmdr(selectFactorsFrame, text="          "),variablenumericaFrame, sticky="nw")
  tkgrid(selectFactorsFrame, sticky="nw")

  tkgrid(labelRcmdr(top, text="          "))
  ###
  tkgrid(labelRcmdr(rightFrame, text="        "),sticky="nw")
  tkgrid(sigmaFrame,sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")
  tkgrid(alternativeFrame,labelRcmdr(optionsFrame, text="          "),rightFrame, sticky="nw")
  tkgrid(optionsFrame,sticky="nw")
  ###

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}




