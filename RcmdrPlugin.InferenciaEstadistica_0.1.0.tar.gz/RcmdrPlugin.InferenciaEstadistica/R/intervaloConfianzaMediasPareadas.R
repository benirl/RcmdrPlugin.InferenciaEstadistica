intervaloConfianzaMediasPareadas <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var1=gettextRcmdr("<no variable selected>"), initial.var2=gettextRcmdr("<no variable selected>"),initial.nconf="0.95")
  dialog.values <- getDialog ("intervaloConfianzaMediasPareadas", defaults)
  initializeDialog(title = gettextRcmdr("Intervalo de Confianza para Medias Pareadas"))

  comboBoxFrame<-tkframe(top)

  selectVariable1ICMediasPareadas <- variableComboBox(comboBoxFrame, variableList=Numeric(),
     initialSelection=dialog.values$initial.var1, title=gettextRcmdr("Primera Variable (Elegir una)"))

  selectVariable2ICMediasPareadas <- variableComboBox(comboBoxFrame, variableList=Numeric(),
                                                      initialSelection=dialog.values$initial.var2, title=gettextRcmdr("Segunda Variable (Elegir una)"))


  nConfianzaFrame<-tkframe(top)

  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
  tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza (1 -alpha):", foreground="blue" ),nConfianzaEntry, sticky="nw")

  onOK <- function(){

    var1ICMedia<-getSelection(selectVariable1ICMediasPareadas)
    var2ICMedia<-getSelection(selectVariable2ICMediasPareadas)

    if(var1ICMedia=="<ninguna variable seleccionada>"){errorCondition(recall=intervaloConfianzaMediasPareadas, message=gettextRcmdr("No seleccionada ninguna variable en Primera Variable"))
      return()}
    if(var2ICMedia=="<ninguna variable seleccionada>"){errorCondition(recall=intervaloConfianzaMediasPareadas, message=gettextRcmdr("No seleccionada ninguna variable en Segunda Variable"))
      return()}

     if(var1ICMedia==var2ICMedia){errorCondition(recall=intervaloConfianzaMediasPareadas, message=gettextRcmdr("Las variables seleccionadas no pueden ser iguales"))
      return()}

    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=intervaloConfianzaMediasPareadas, message=gettextRcmdr("Valor no v�lido para nivel de confianza, n�mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}


    putDialog ("intervaloConfianzaMediasPareadas", list(initial.var1=var1ICMedia,initial.var2=var2ICMedia,initial.nconf=valornConfianza))
    closeDialog()


###################### Imprimir la funci?n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()

    vICMedia1<-paste(.activeDataSet,"$",var1ICMedia, sep="")
    vICMedia2<-paste(.activeDataSet,"$",var2ICMedia, sep="")

   # command<- paste("calcular_ICMediasPareadas(v.primera=", v1ICMedia,", v.segunda=", v2ICMedia,", nivel.confianza=",valornConfianza,")",sep="" )
   #  doItAndPrint(command)

  command2<- paste("aux<-t.test(",vICMedia1,", ",vICMedia2,", paired = TRUE, conf.level=",valornConfianza,")",sep="")

  tipointervalo<-"\\nINTERVALO DE CONFIANZA PARA LA DIFERENCIA DE MEDIAS PAREADAS\\n"
  linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
  tipointervalo<-paste(tipointervalo, linaux,sep="")


  command2<- paste("local({\n",command2,"\n",'aux2<-as.vector(aux[["conf.int"]]) \n',sep="")

  resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nVariables: ", var1ICMedia," vs. ",var2ICMedia, "\\n",'")', sep="" )
  command2<- paste(command2, resultado,"\n",sep="" )
  command2<-paste(command2,'cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")',"\n",sep="")
  command2<-paste(command2,'cat("Intervalo: (",aux2[1],",",aux2[2],")\\n")',"\n})",sep="")

  doItAndPrint(command2)

###############################################################################################################

    ##calcular_ICMediasPareadas(v.numerica=variableICMedia,varianza.conocida=varConocida,valor.varianza=valorvarianza, nivel.confianza=valornConfianza)

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "t.test", reset="intervaloConfianzaMediasPareadas", apply="intervaloConfianzaMediasPareadas")

  tkgrid(getFrame(selectVariable1ICMediasPareadas),labelRcmdr(comboBoxFrame, text="          "),getFrame(selectVariable2ICMediasPareadas), sticky="nw")
  tkgrid(comboBoxFrame, sticky="nw")
  tkgrid(labelRcmdr(top, text="          "), sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")
  tkgrid(buttonsFrame, sticky="w")

  dialogSuffix()
}


