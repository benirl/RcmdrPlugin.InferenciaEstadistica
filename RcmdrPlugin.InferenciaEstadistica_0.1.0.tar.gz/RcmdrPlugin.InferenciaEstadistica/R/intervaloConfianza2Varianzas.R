intervaloConfianza2Varianzas <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var="<ninguna variable seleccionada>",initial.nconf="0.95")
  dialog.values <- getDialog ("intervaloConfianza2Varianzas", defaults)
  initializeDialog(title = gettextRcmdr("Intervalo de Confianza para Cociente Varianzas"))

##Creaci�n de los ComboBox

  selectFactorsFrame<-tkframe(top)
  comboBoxFrame<-tkframe(selectFactorsFrame)

  twoOrMoreLevelFactors<-twoOrMoreLevelFactors() ##NULL SI NO ACTIVEDATASET

  if (length(twoOrMoreLevelFactors())!=0){
    mostrar<-"readonly"
  }else {
    mostrar<-"disabled"
  }


  valuescombo_box<-c("<ninguna variable seleccionada>",twoOrMoreLevelFactors())
  varcombo_box=tclVar(valuescombo_box[1])

  combo_box<-ttkcombobox(comboBoxFrame,values=valuescombo_box,textvariable=varcombo_box,state=mostrar)
  tkgrid(labelRcmdr(comboBoxFrame, text="Grupos (Elegir uno)", foreground="blue" ), sticky="nw")
  tkgrid(combo_box,sticky="nw")


  tkbind(combo_box, "<<ComboboxSelected>>",function(){

    value<-tclvalue(varcombo_box)
    if(value!="<ninguna variable seleccionada>"){
      datasetactivo <- ActiveDataSet()
      datasetactivo<-get(datasetactivo)
      niveles<-levels(datasetactivo[,value])
      tkconfigure(combo_box2,values=niveles)
      tclvalue(varcombo_box2)<-niveles[1]
      tk2state.set(combo_box2, state="readonly")
      tkconfigure(combo_box3,values=niveles)
      tclvalue(varcombo_box3)<-niveles[2]
      tk2state.set(combo_box3, state="readonly")
      tkfocus(combo_box2)}
    else{tk2state.set(combo_box2, state="disabled")
         niveles<-"<ninguna variable seleccionada>"
          tkconfigure(combo_box2,values=niveles)
          tclvalue(varcombo_box2)<-niveles
          tkconfigure(combo_box3,values=niveles)
          tclvalue(varcombo_box3)<-niveles}})

  varcombo_box2=tclVar("<ninguna variable seleccionada>")
  combo_box2<-ttkcombobox(comboBoxFrame,values=varcombo_box2,textvariable=varcombo_box2,state="disabled")

  tkgrid(labelRcmdr(comboBoxFrame, text="Grupo 1", foreground="blue" ), sticky="nw")
  tkgrid(combo_box2, sticky="nw")

  varcombo_box3=tclVar("<ninguna variable seleccionada>")
  combo_box3<-ttkcombobox(comboBoxFrame,values=varcombo_box3,textvariable=varcombo_box3,state="disabled")

  tkgrid(labelRcmdr(comboBoxFrame, text="Grupo 2", foreground="blue" ), sticky="nw")
  tkgrid(combo_box3, sticky="nw")

##Fin creaci�n comboBox

  variablenumericaFrame<-tkframe(top)
  selectVariableICMedia <- variableComboBox(variablenumericaFrame, variableList=Numeric(),
  initialSelection=dialog.values$initial.var, title=gettextRcmdr("Variable (Elegir una)"))
  tkgrid(getFrame(selectVariableICMedia), sticky="nw")


#### Inicio Nivel Confianza(Frame)
    nConfianzaFrame<-tkframe(top)

  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
  tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza: (1-alpha)", foreground="blue" ),nConfianzaEntry, sticky="nw")

  onOK <- function(){

    grupoICVarianzas<-tclvalue(varcombo_box)
    if(grupoICVarianzas=="<ninguna variable seleccionada>"){errorCondition(recall=intervaloConfianza2Varianzas, message=gettextRcmdr("No seleccionada ning�n Grupo"))
      return()}
    if ((length(twoOrMoreLevelFactors)!=0)&&(grupoICVarianzas !="<ninguna variable seleccionada>")){
      varGrupo1<-tclvalue(varcombo_box2)
      varGrupo2<-tclvalue(varcombo_box3)}
    else {
      variableICProporcion<-NULL
      varGrupo1<-NULL
      varGrupo2<-NULL
    }


    varICVarianzas<-getSelection(selectVariableICMedia)
    if(varICVarianzas=="<ninguna variable seleccionada>"){errorCondition(recall=intervaloConfianza2Varianzas, message=gettextRcmdr("No seleccionada ninguna variable"))
      return()}

    if(varGrupo1==varGrupo2){errorCondition(recall=intervaloConfianza2Varianzas, message=gettextRcmdr("Grupo 1 y 2 no pueden tener seleccionado el mismo valor"))
      return()}


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=intervaloConfianza2Varianzas, message=gettextRcmdr("Valor no valido para nivel de confianza, n?mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}


    putDialog ("intervaloConfianza2Varianzas", list(initial.var=varICVarianzas,initial.nconf=valornConfianza))
    closeDialog()


###################### Imprimir la funci�n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()
    level1<-tclvalue(varcombo_box2)
    level2<-tclvalue(varcombo_box3)

     vICGrupos<-paste(.activeDataSet,"$",grupoICVarianzas, sep="")

    vLevelGrupos<-paste("c(",'"',tclvalue(varcombo_box2),'"',",",'"',tclvalue(varcombo_box3),'"',")",sep="")

    vVariable<-paste(.activeDataSet,"$",varICVarianzas, sep="")


#  command<- paste("calcular_IC2Varianzas(grupo =", vICGrupos,", levels.grupo =", vLevelGrupos,", variable =", vVariable,", nivel.confianza=",valornConfianza,")",sep="" )
#  doItAndPrint(command)

    command2<- paste("local({\n","var1<-subset(",.activeDataSet,",", grupoICVarianzas,"==",'"',level1,'"',", select=",varICVarianzas,")",sep="")
    command2<- paste(command2,"\n","var2<-subset(",.activeDataSet,",", grupoICVarianzas,"==",'"',level2,'"',", select=",varICVarianzas,")",sep="")

    command2<-paste(command2,"\n","aux<- var.test(var1[,1], var2[,1], conf.level=",valornConfianza,")",sep="")

    tipointervalo<-"\\nINTERVALO DE CONFIANZA PARA EL COCIENTE DE VARIANZAS \\n"
    linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
    tipointervalo<-paste(tipointervalo, linaux,sep="")


    command2<- paste(command2,"\n",'aux2<-as.vector(aux[["conf.int"]]) \n',sep="")

    resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nVariable: ", varICVarianzas,"\\nGrupos: ",grupoICVarianzas," [",level1," vs. ", level2 ,"]\\n",'")', sep="" )
    command2<- paste(command2, resultado,"\n",sep="" )
    command2<-paste(command2,'cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")',"\n",sep="")

    command2<-paste(command2,'cat("Intervalo: (",aux2[1],",",aux2[2],")\\n")',"\n})",sep="")

    doItAndPrint(command2)



###############################################################################################################

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "var.test", reset="intervaloConfianza2Varianzas", apply="intervaloConfianza2Varianzas")

  tkgrid(comboBoxFrame,labelRcmdr(selectFactorsFrame, text="          "),variablenumericaFrame, sticky="nw")
  tkgrid(selectFactorsFrame, sticky="nw")

  tkgrid(labelRcmdr(top, text="          "))
  tkgrid(nConfianzaFrame, sticky="nw")

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}




