intervaloConfianzaProporcion <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.nexitos="",initial.nfracasos="",initial.nconf="0.95")
  dialog.values <- getDialog ("intervaloConfianzaProporcion", defaults)
  initializeDialog(title = gettextRcmdr("Intervalo de Confianza Proporci�n"))

##Creaci?n de los ComboBox

  selectFactorsFrame<-tkframe(top)
  comboBoxFrame<-tkframe(selectFactorsFrame)

  twoOrMoreLevelFactors<-twoOrMoreLevelFactors() ##NULL SI NO ACTIVEDATASET

  if (length(twoOrMoreLevelFactors())!=0){
    mostrar<-"readonly"
  }else {
    mostrar<-"disabled"
  }


  valuescombo_box<-c("<ninguna variable seleccionada>",twoOrMoreLevelFactors())
  varcombo_box=tclVar(valuescombo_box[1])

  combo_box<-ttkcombobox(comboBoxFrame,values=valuescombo_box,textvariable=varcombo_box,state=mostrar)
  tkgrid(labelRcmdr(comboBoxFrame, text="Factor de dos o m�s niveles(Elegir uno)", foreground="blue" ), sticky="nw")
  tkgrid(combo_box,sticky="nw")

  tkbind(combo_box, "<<ComboboxSelected>>",function(){

    value<-tclvalue(varcombo_box)
    if(value!="<ninguna variable seleccionada>"){
      datasetactivo <- ActiveDataSet()
      datasetactivo<-get(datasetactivo)
      niveles<-levels(datasetactivo[,value])
      tkconfigure(combo_box2,values=niveles)
      tclvalue(varcombo_box2)<-niveles[1]
      tk2state.set(combo_box2, state="readonly")
      tkfocus(combo_box2)}
    else{tk2state.set(combo_box2, state="disabled")
         niveles<-"<ninguna variable seleccionada>"
          tkconfigure(combo_box2,values=niveles)
          tclvalue(varcombo_box2)<-niveles}})

  varcombo_box2=tclVar("<ninguna variable seleccionada>")
  combo_box2<-ttkcombobox(comboBoxFrame,values=varcombo_box2,textvariable=varcombo_box2,state="disabled")

  tkgrid(labelRcmdr(comboBoxFrame, text="Proporci�n para el nivel(Elegir uno)", foreground="blue" ), sticky="nw")
  tkgrid(combo_box2, sticky="nw")

##Fin creaci?n comboBox



  exitosFracasosFrame<-tkframe(top)

  nExitosVar<-tclVar(dialog.values$initial.nexitos)
  nExitosEntry<-ttkentry(exitosFracasosFrame,width="5",textvariable=nExitosVar)
  tkgrid(labelRcmdr(exitosFracasosFrame, text="N�mero Exitos:", foreground="blue" ),nExitosEntry, sticky="nw")




  nFracasosVar<-tclVar(dialog.values$initial.nfracasos)
  nFracasosEntry<-ttkentry(exitosFracasosFrame,width="5",textvariable=nFracasosVar)
  tkgrid(labelRcmdr(exitosFracasosFrame, text="N�mero Fracasos:", foreground="blue" ),nFracasosEntry, sticky="nw")

  nConfianzaFrame<-tkframe(top)

  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
  tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza:", foreground="blue" ),nConfianzaEntry, sticky="nw")

  onOK <- function(){

    varICProporcion<-tclvalue(varcombo_box)
    if ((length(twoOrMoreLevelFactors)!=0)&&(varICProporcion !="<ninguna variable seleccionada>")){
      activeDataSet <- ActiveDataSet()
      activeDataSet<-get(activeDataSet)
      variableICProporcion<-activeDataSet[,varICProporcion]
      variableLevelICProporcion<-tclvalue(varcombo_box2)}
    else {
      variableICProporcion<-NULL
      variableLevelICProporcion<-NULL
    }

    valornexitos<-tclvalue(nExitosVar)
                if( (valornexitos!="") && (is.na(as.integer(valornexitos)) || (as.integer(valornexitos)<0))) {
                  valornexitos=""
                  errorCondition(recall=intervaloConfianzaProporcion, message=gettextRcmdr("Valor n�mero exitos no es un n�mero entero mayor o igual que 0"))
                  return()
                }
                else{if(valornexitos!=""){valornexitos<-as.integer(valornexitos)}}

    valornfracasos<-tclvalue(nFracasosVar)
    if((valornfracasos!="") && (is.na(as.integer(valornfracasos)) || (as.integer(valornfracasos)<0))){
      valornfracasos=""
      errorCondition(recall=intervaloConfianzaProporcion, message=gettextRcmdr("Valor n�mero fracasos no es un n�mero entero mayor o igual que 0"))
      return()
    }
    else{if(valornfracasos!=""){valornfracasos<-as.integer(valornfracasos)}}


   if ((is.null(variableICProporcion))&&((valornexitos=="")||(valornfracasos==""))){
      errorCondition(recall=intervaloConfianzaProporcion, message=gettextRcmdr("Tu debes seleccionar una variable o indicar el n�mero de exitos y n�mero de fracasos."))
      return()
    }

    sumaexitosfracasos<-sum(as.integer(valornexitos),as.integer(valornfracasos))

    if ((is.null(variableICProporcion))&&(sumaexitosfracasos==0)){
      errorCondition(recall=intervaloConfianzaProporcion, message=gettextRcmdr("Tu debes seleccionar una variable o la suma de los enteros positivos del n�mero de exitos y fracasos debe ser mayor que 0"))
      return()
    }

    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=intervaloConfianzaProporcion, message=gettextRcmdr("Valor no valido para nivel de confianza, n?mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}


    putDialog ("intervaloConfianzaProporcion", list(initial.nexitos=valornexitos,initial.nfracasos=valornfracasos,initial.nconf="0.95"))
    closeDialog()

   ##variableICProporcion TwoLevelFactoSeleccionado o nada
    valornexitos<-as.integer(valornexitos)
    valornfracasos<-as.integer(valornfracasos)
    valornConfianza<-as.numeric(valornConfianza)

###################### Imprimir la funci?n a llamar por RCommander ###########################################

    .activeDataSet<-ActiveDataSet()

    if ((length(twoOrMoreLevelFactors)!=0)&&(varICProporcion !="<ninguna variable seleccionada>")){
      vICProporcion<-paste(.activeDataSet,"$",varICProporcion, sep="")
      vLevelICProporcion<-paste('"',tclvalue(varcombo_box2),'"',sep="")}
    else {
      vICProporcion<-NULL
      vLevelICProporcion<-NULL
    }

    if(!is.null(vICProporcion)){

    command<- paste("exitos<-sum(",vICProporcion," == ", vLevelICProporcion,")",sep="")
    command<- paste(command,"\n","total<-length(",vICProporcion,")",sep="")
    command<-paste(command,"\n","aux<- Cprop.test(ex=exitos, nx=total, conf.level=",valornConfianza,")",sep="")
    command<- paste(command,"\n","levelsaux<-levels(",vICProporcion,")",sep="")
    command<- paste(command,"\n","levelsaux<-levelsaux[levelsaux!=",vLevelICProporcion,"]",sep="")
    tipointervalo<-paste("\\nINTERVALO DE CONFIANZA PARA LA PROPORCION DE UN NIVEL DE UNA VARIABLE CUALITATIVA ","\\n", sep="")
    linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
    tipointervalo<-paste(tipointervalo, linaux,sep="")


    command<- paste("local({\n",command,"\n",'aux2<-as.vector(aux[["conf.int"]]) \n',sep="")

    if(length(levels(variableICProporcion))<=5){
    resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nVariable: ", varICProporcion," [",tclvalue(varcombo_box2),'"," vs.", levelsaux,"] --> N� Exitos = ",exitos," -- N� Intentos =", total,"\\n"',')', sep="" )}
    else{resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nVariable: ", varICProporcion," [",tclvalue(varcombo_box2),'"," vs. others_levels] --> N� Exitos = ",exitos," -- N� Intentos =", total,"\\n"',')', sep="" )}

    command<- paste(command, resultado,"\n",sep="" )
    command<-paste(command,'cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")',"\n",sep="")
    command<-paste(command,'cat("Intervalo: (",aux2[1],",",aux2[2],")\\n")',"\n})",sep="")
    doItAndPrint(command)
    }

    if(!is.na(valornexitos)){

    command2<- paste("aux<- Cprop.test(ex=",valornexitos,", nx=",valornexitos + valornfracasos,", conf.level=",valornConfianza,")",sep="" )
    tipointervalo<-paste("\\nINTERVALO DE CONFIANZA PARA PROPORCI�N DE UNA MUESTRA ","\\n", sep="")
    linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
    tipointervalo<-paste(tipointervalo, linaux,sep="")


      command2<- paste("local({\n",command2,"\n",'aux2<-as.vector(aux[["conf.int"]]) \n',sep="")

      resultado<-paste('cat("',tipointervalo, "\\nNivel de confianza: " , valornConfianza*100,"%\\nMuestra: N�m. exitos = ", valornexitos, " -- N�m. fracasos = ", valornfracasos,"\\n",'")', sep="" )
      command2<- paste(command2, resultado,"\n",sep="" )
      command2<-paste(command2,'cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")',"\n",sep="")
      command2<-paste(command2,'cat("Intervalo: (",aux2[1],",",aux2[2],")\\n")',"\n})",sep="")
      doItAndPrint(command2)


    }

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "Cprop.test", reset="intervaloConfianzaProporcion", apply="intervaloConfianzaProporcion")

  tkgrid(comboBoxFrame,labelRcmdr(selectFactorsFrame, text="          "),exitosFracasosFrame, sticky="nw")
  tkgrid(selectFactorsFrame, sticky="nw")

  tkgrid(labelRcmdr(top, text="          "))
  tkgrid(nConfianzaFrame, sticky="nw")

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}




