contrasteHipotesisDiferenciaProporciones <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.nexitos="",initial.nfracasos="",initial.nexitos2="",initial.nfracasos2="",initial.nconf="0.95",initial.alternative = "two.sided",initial.diferenciaProporciones = "0.0")
  dialog.values <- getDialog ("contrasteHipotesisDiferenciaProporciones", defaults)
  initializeDialog(title = gettextRcmdr("Contraste Hip�tesis Diferencia Proporciones"))

seleccionFrame<-tkframe(top)
selectFactorsFrame<-ttkframe(seleccionFrame, borderwidth=1, relief="solid", padding=c(5,5,8,8))

  ##Creaci�n de los ComboBox 1

  comboBoxFrame<-ttklabelframe(selectFactorsFrame, text="Variable 1", padding=c(5,5,5,5))

  twoOrMoreLevelFactors<-twoOrMoreLevelFactors() ##NULL SI NO ACTIVEDATASET

  if (length(twoOrMoreLevelFactors())!=0){
    mostrar<-"readonly"
  }else {
    mostrar<-"disabled"
  }


  valuescombo_box<-c("<ninguna variable seleccionada>",twoOrMoreLevelFactors())
  varcombo_box=tclVar(valuescombo_box[1])

  DatosFrame<-tkframe(comboBoxFrame)
  combo_box<-ttkcombobox(DatosFrame,values=valuescombo_box,textvariable=varcombo_box,state=mostrar)

  Eti<-labelRcmdr(DatosFrame, text="Datos : ")
  tkgrid(Eti, combo_box, sticky="nw")
  tkgrid(DatosFrame, sticky="nw")


  tkbind(combo_box, "<<ComboboxSelected>>",function(){

    value<-tclvalue(varcombo_box)
    if(value!="<ninguna variable seleccionada>"){
      datasetactivo <- ActiveDataSet()
      datasetactivo<-get(datasetactivo)
      niveles<-levels(datasetactivo[,value])
      tkconfigure(combo_box2,values=niveles)
      tclvalue(varcombo_box2)<-niveles[1]
      tk2state.set(combo_box2, state="readonly")
      tkfocus(combo_box2)}
    else{tk2state.set(combo_box2, state="disabled")
         niveles<-"<ninguna variable seleccionada>"
          tkconfigure(combo_box2,values=niveles)
          tclvalue(varcombo_box2)<-niveles}})

  ExitoFrame<-tkframe(comboBoxFrame)
  varcombo_box2=tclVar("<ninguna variable seleccionada>")
  combo_box2<-ttkcombobox(ExitoFrame,values=varcombo_box2,textvariable=varcombo_box2,state="disabled")
  # tkgrid(labelRcmdr(ExitoFrame, text=""),sticky="nw")
  Etiqueta<-labelRcmdr(ExitoFrame, text="Exito:    ")
  tkgrid(Etiqueta, combo_box2, sticky="nw")
  tkgrid(ExitoFrame, sticky="nw")

##Fin creaci?n comboBox

##Creaci�n de los ComboBox 2

  comboBoxFrame2<-ttklabelframe(selectFactorsFrame, text="Variable 2", padding=c(5,5,5,5))

  valuescombo_box3<-c("<ninguna variable seleccionada>",twoOrMoreLevelFactors())
  varcombo_box3=tclVar(valuescombo_box3[1])

  DatosFrame2<-tkframe(comboBoxFrame2)
  combo_box3<-ttkcombobox(DatosFrame2,values=valuescombo_box3,textvariable=varcombo_box3,state=mostrar)

  Eti3<-labelRcmdr(DatosFrame2, text="Datos : ")
  tkgrid(Eti3, combo_box3, sticky="nw")
  tkgrid(DatosFrame2, sticky="nw")


  tkbind(combo_box3, "<<ComboboxSelected>>",function(){

    value<-tclvalue(varcombo_box3)
    if(value!="<ninguna variable seleccionada>"){
      datasetactivo <- ActiveDataSet()
      datasetactivo<-get(datasetactivo)
      niveles<-levels(datasetactivo[,value])
      tkconfigure(combo_box4,values=niveles)
      tclvalue(varcombo_box4)<-niveles[1]
      tk2state.set(combo_box4, state="readonly")
    }
    else{tk2state.set(combo_box4, state="disabled")
      niveles<-"<ninguna variable seleccionada>"
      tkconfigure(combo_box4,values=niveles)
      tclvalue(varcombo_box4)<-niveles}})

  Exito2Frame<-tkframe(comboBoxFrame2)
  varcombo_box4=tclVar("<ninguna variable seleccionada>")
  combo_box4<-ttkcombobox(Exito2Frame,values=varcombo_box4,textvariable=varcombo_box4,state="disabled")
  # tkgrid(labelRcmdr(Exito2Frame, text=""),sticky="nw")
  Etiqueta2<-labelRcmdr(Exito2Frame, text="Exito:    ")
  tkgrid(Etiqueta2, combo_box4, sticky="nw")
  tkgrid(Exito2Frame, sticky="nw")


##Fin creaci�n comboBox2



muestrasFrame<-ttkframe(seleccionFrame, borderwidth=1, relief="solid", padding=c(5,5,8,8))
 # muestrasFrame<-ttklabelframe(top, text="Muestras no conocidas", padding=c(5,5,8,8))

## Inico exitos y fracasos Muestra1


  muestra1Frame<-ttklabelframe(muestrasFrame, text="Muestra 1", padding=c(5,5,5,5))

  exitosFracasosFrame<-tkframe(muestra1Frame)
  nExitosVar<-tclVar(dialog.values$initial.nexitos)
  nExitosEntry<-ttkentry(exitosFracasosFrame,width="5",textvariable=nExitosVar)
  tkgrid(labelRcmdr(exitosFracasosFrame, text="Exitos:"),nExitosEntry, sticky="nw")

  nFracasosVar<-tclVar(dialog.values$initial.nfracasos)
  nFracasosEntry<-ttkentry(exitosFracasosFrame,width="5",textvariable=nFracasosVar)
  tkgrid(labelRcmdr(exitosFracasosFrame, text="Fracasos:"),nFracasosEntry, sticky="nw")

#  tkgrid(labelRcmdr(muestra1Frame, text="     Muestra 1   ", foreground="blue" ), sticky="nwe")
  tkgrid(exitosFracasosFrame,sticky="nw")
  tkgrid(muestra1Frame, sticky="nw")

##Fin exitos y fracasos Muestra 1

## Inico exitos y fracasos Muestra 2


  muestra2Frame<-ttklabelframe(muestrasFrame, text="Muestra 2", padding=c(5,5,5,5))

  exitosFracasosFrame2<-tkframe(muestra2Frame)
  nExitosVar2<-tclVar(dialog.values$initial.nexitos2)
  nExitosEntry2<-ttkentry(exitosFracasosFrame2,width="5",textvariable=nExitosVar2)
  tkgrid(labelRcmdr(exitosFracasosFrame2, text="Exitos:" ),nExitosEntry2, sticky="nw")
  nFracasosVar2<-tclVar(dialog.values$initial.nfracasos2)
  nFracasosEntry2<-ttkentry(exitosFracasosFrame2,width="5",textvariable=nFracasosVar2)
  tkgrid(labelRcmdr(exitosFracasosFrame2, text="Fracasos:"),nFracasosEntry2, sticky="nw")
 # tkgrid(labelRcmdr(muestra1Frame, text="     Muestra 2   ", foreground="blue" ), sticky="nwe")
  tkgrid(exitosFracasosFrame2,sticky="nw")
  tkgrid(muestra2Frame, sticky="nw")

  ##Fin exitos y fracasos Muestra 2

  #### Inicio Contraste Hipotesis Alternativa, Nula y Nivel Confianza (Frame)

  optionsFrame <- tkframe(top)
  radioButtons(optionsFrame, name = "alternative", buttons = c("twosided",
                                                               "less", "greater"), values = c("two.sided", "less", "greater"),
               labels = gettextRcmdr(c("Diferencia Poblacional != p0_1 - p0_2", "Diferencia Poblacional < p0_1 - p0_2",
                                       "Diferencia Poblacional > p0_1 - p0_2")), title = gettextRcmdr("Alternative Hypothesis"),
               initialValue = dialog.values$initial.alternative)


  rightFrame<-tkframe(top)

  diferenciaProporcionesFrame <- tkframe(rightFrame)
  diferenciaProporcionesVariable <- tclVar(dialog.values$initial.diferenciaProporciones)
  diferenciaProporcionesField <- ttkentry(diferenciaProporcionesFrame, width = "5", textvariable = diferenciaProporcionesVariable)
  tkgrid(labelRcmdr(diferenciaProporcionesFrame, text="Hip�tesis Nula: p0_1 - p0_2 = ", foreground="blue" ), diferenciaProporcionesField, sticky="nw")

  nConfianzaFrame<-tkframe(rightFrame)
  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
  #tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza (1-alpha)= ", foreground="blue" ),nConfianzaEntry, sticky="nw")

  #######################################

  onOK <- function(){

    varICProporcion<-tclvalue(varcombo_box)
    if ((length(twoOrMoreLevelFactors)!=0)&&(varICProporcion !="<ninguna variable seleccionada>")){
      variableICProporcion<-tclvalue(varcombo_box)
      variableLevelICProporcion<-tclvalue(varcombo_box2)}
    else {
      variableICProporcion<-NULL
      variableLevelICProporcion<-NULL
    }

    varICProporcion2<-tclvalue(varcombo_box3)
    if ((length(twoOrMoreLevelFactors)!=0)&&(varICProporcion2 !="<ninguna variable seleccionada>")){
      variableICProporcion2<-tclvalue(varcombo_box3)
      variableLevelICProporcion2<-tclvalue(varcombo_box4)}
    else {
      variableICProporcion2<-NULL
      variableLevelICProporcion2<-NULL
    }




    valornexitos<-tclvalue(nExitosVar)
                if( (valornexitos!="") && (is.na(as.integer(valornexitos)) || (as.integer(valornexitos)<0))) {
                  valornexitos=""
                  errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor n�mero exitos Muestra 1 no es un n�mero entero mayor o igual que 0"))
                  return()
                }
                else{if(valornexitos!=""){valornexitos<-as.integer(valornexitos)}}

    valornfracasos<-tclvalue(nFracasosVar)
    if((valornfracasos!="") && (is.na(as.integer(valornfracasos)) || (as.integer(valornfracasos)<0))){
      valornfracasos=""
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor n�mero fracasos Muestra 1 no es un n�mero entero mayor o igual que 0"))
      return()
    }
    else{if(valornfracasos!=""){valornfracasos<-as.integer(valornfracasos)}}


    valornexitos2<-tclvalue(nExitosVar2)
    if( (valornexitos2!="") && (is.na(as.integer(valornexitos2)) || (as.integer(valornexitos2)<0))) {
      valornexitos2=""
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor n�mero exitos Muestra 2 no es un n�mero entero mayor o igual que 0"))
      return()
    }
    else{if(valornexitos2!=""){valornexitos2<-as.integer(valornexitos2)}}

    valornfracasos2<-tclvalue(nFracasosVar2)
    if((valornfracasos2!="") && (is.na(as.integer(valornfracasos2)) || (as.integer(valornfracasos2)<0))){
      valornfracasos2=""
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor n�mero fracasos 2 no es un n�mero entero mayor o igual que 0"))
      return()
    }
    else{if(valornfracasos2!=""){valornfracasos2<-as.integer(valornfracasos2)}}


   if ((is.null(variableICProporcion)||is.null(variableICProporcion2)) && (((valornexitos=="")||(valornfracasos==""))||((valornexitos2=="")||(valornfracasos2=="")))){
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Tu debes seleccionar las variables del dato activo o indicar dos muestras reflejando el n�mero de exitos y n�mero de fracasos."))
      return()
    }

    sumaexitosfracasos<-sum(as.integer(valornexitos),as.integer(valornfracasos))
    sumaexitosfracasos2<-sum(as.integer(valornexitos2),as.integer(valornfracasos2))

    if ((is.null(variableICProporcion)||is.null(variableICProporcion2))&&(sumaexitosfracasos==0 ||sumaexitosfracasos2==0)){
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Tu debes seleccionar una variable o la suma de los enteros positivos del n�mero de exitos y fracasos debe ser mayor que 0"))
      return()
    }


    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor no v�lido para nivel de confianza, n�mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}

    valordiferenciaProporciones<-tclvalue(diferenciaProporcionesVariable)

    if(is.na(as.numeric(valordiferenciaProporciones))|| (as.numeric(valordiferenciaProporciones)<0)||(as.numeric(valordiferenciaProporciones)>1)){
      valordiferenciaProporciones="0.0"
      errorCondition(recall=contrasteHipotesisDiferenciaProporciones, message=gettextRcmdr("Valor no v�lido para la Hip�tesis Nula p0, n�mero de 0 y 1"))
      return()
    }
    else{ valordiferenciaProporciones<-as.numeric(valordiferenciaProporciones)}

    varHAlternativa<-tclvalue(alternativeVariable)


    putDialog ("contrasteHipotesisDiferenciaProporciones", list(initial.nexitos=valornexitos,initial.nfracasos=valornfracasos,initial.nexitos2=valornexitos2,initial.nfracasos2=valornfracasos2,initial.nconf="0.95",
                                                                initial.alternative = varHAlternativa,initial.diferenciaProporciones = valordiferenciaProporciones))
    closeDialog()

   ##variableICProporcion TwoLevelFactoSeleccionado o nada
    valornexitos<-as.integer(valornexitos)
    valornfracasos<-as.integer(valornfracasos)
    valornexitos2<-as.integer(valornexitos2)
    valornfracasos2<-as.integer(valornfracasos2)
    valornConfianza<-as.numeric(valornConfianza)

###################### Imprimir la funci�n a llamar por RCommander ###########################################

    .activeDataSet<-ActiveDataSet()

    if ((length(twoOrMoreLevelFactors)!=0)&&(varICProporcion !="<ninguna variable seleccionada>")&&(varICProporcion2 !="<ninguna variable seleccionada>")){

      vICProporcion<-paste(.activeDataSet,"$",varICProporcion, sep="")
      vICProporcion2<-paste(.activeDataSet,"$",varICProporcion2, sep="")
      vLevelICProporcion<-paste('"',tclvalue(varcombo_box2),'"',sep="")
      vLevelICProporcion2<-paste('"',tclvalue(varcombo_box4),'"',sep="")}
    else {
      vICProporcion<-NULL
      vICProporcion2<-NULL
      vLevelICProporcion<-NULL
      vLevelICProporcion2<-NULL
    }

    Haltern<-paste('"',varHAlternativa,'"',sep="")

    if(!is.null(vICProporcion)){

      command<- paste("exitos<-sum(",vICProporcion," == ", vLevelICProporcion,")",sep="")
      command<- paste(command,"\n","total<-length(",vICProporcion,")",sep="")
      command<- paste(command,"\n","exitos2<-sum(",vICProporcion2," == ", vLevelICProporcion2,")",sep="")
      command<- paste(command,"\n","total2<-length(",vICProporcion2,")",sep="")
      command<- paste(command,"\n","aux<- Cprop.test(ex=exitos, nx=total,ey=exitos2,ny=total2, p.null=",valordiferenciaProporciones,", alternative=",Haltern,")",sep="")
      tipointervalo<-paste("\\nCONTRASTE DE HIP�TESIS PARA LA DIFERENCIA DE PROPORCIONES VARIABLE 1 Y 2 ","\\n", sep="")
      linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
      tipointervalo<-paste(tipointervalo, linaux,sep="")

      command<- paste("local({\n",command,"\n",sep="")

      resultado<-paste('cat("',tipointervalo, "\\nVariable 1: ", varICProporcion," [",tclvalue(varcombo_box2),'"," vs. other_levels] --> N� �xitos = ",exitos," -- N� Intentos =", total',',"\\nVariable 2: ","', varICProporcion2," [",tclvalue(varcombo_box4),'"," vs. others_levels]--> N� �xitos = ",exitos2," -- N� Intentos =", total2,"\\n"',')', sep="" )
      command<- paste(command, resultado,"\n",sep="" )
      distribucion<-'cat("Distribuci�n:",names(aux$statistic),"con distribuci�n N(0,1)\\n")'
      e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'

      p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
      if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
      if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
      if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}'


      if (varHAlternativa == "two.sided"){h.alt<-paste("Media poblacional no es igual a Hipotesis Nula = ",valordiferenciaProporciones,sep="")}
      if (varHAlternativa == "less"){h.alt<-paste("Media poblacional es menor a Hipotesis Nula = ",valordiferenciaProporciones,sep="")}
      if (varHAlternativa == "greater"){h.alt<- paste("Media poblacional es mayor a Hipotesis Nula = ",valordiferenciaProporciones,sep="")}
      h.alt<-paste('\n cat("Hipotesis Alternativa:","',h.alt,'","\\n")')

      e.muestral<-'\n cat("Estimadores Muestrales:",names(aux$estimate)[1],as.numeric(aux$estimate)[1],",", names(aux$estimate)[2],as.numeric(aux$estimate)[2],"\\n")'

      command<- paste(command, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

      doItAndPrint(command)

    }

    if(!is.na(valornexitos)){

      command2<- paste("aux<- Cprop.test(ex=",valornexitos,", nx=",valornexitos + valornfracasos,", ey=",valornexitos2,", ny=",valornexitos2 + valornfracasos2,", p.null=",valordiferenciaProporciones,", alternative=",Haltern,")",sep="")
      tipointervalo<-paste("\\nCONTRASTE DE HIP�TESIS PARA LA DIFERENCIA DE PROPORCIONES DE DOS MUESTRAS ","\\n", sep="")
      linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
      tipointervalo<-paste(tipointervalo, linaux,sep="")

      command2<- paste("local({\n",command2,"\n",sep="")

      resultado<-paste('cat("',tipointervalo, "\\nMuestra 1: N� �xitos = ", valornexitos ," -- N� Fracasos = ", valornfracasos,"\\nMuestra 2: N� �xitos = ", valornexitos2 ," -- N� Fracasos = ", valornfracasos2,'\\n")', sep="" )
      command2<- paste(command2, resultado,"\n",sep="" )
      distribucion<-'cat("Distribuci�n:",names(aux$statistic),"con distribuci�n N(0,1)\\n")'
      e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'

      p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
      if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
      if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
      if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}'


      if (varHAlternativa == "two.sided"){h.alt<-paste("Media poblacional no es igual a Hiptesis Nula = ",valordiferenciaProporciones,sep="")}
      if (varHAlternativa == "less"){h.alt<-paste("Media poblacional es menor a Hip�tesis Nula = ",valordiferenciaProporciones,sep="")}
      if (varHAlternativa == "greater"){h.alt<- paste("Media poblacional es mayor a Hip�tesis Nula = ",valordiferenciaProporciones,sep="")}
      h.alt<-paste('\n cat("Hip�tesis Alternativa:","',h.alt,'","\\n")')

      e.muestral<-'\n cat("Estimadores Muestrales:",names(aux$estimate)[1],as.numeric(aux$estimate)[1],",", names(aux$estimate)[2],as.numeric(aux$estimate)[2],"\\n")'

      command2<- paste(command2, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

      doItAndPrint(command2)

    }
  # command<- paste("calcular_CHDiferenciaProporciones(variable1 =", vICProporcion,", level.variable1 =", vLevelICProporcion,",variable2 =", vICProporcion2,", level.variable2 =", vLevelICProporcion2,", n.exitos.muestra1=", valornexitos,", n.fracasos.muestra1=", valornfracasos,", n.exitos.muestra2=", valornexitos2,", n.fracasos.muestra2=", valornfracasos2,", hipotesis.alternativa=",Haltern,", hipotesis.nula=",valordiferenciaProporciones,", nivel.confianza=",valornConfianza,")",sep="" )

  #  doItAndPrint(command)



###############################################################################################################


  ##  calcular_CHDiferenciaProporciones(factor.twoormorelevels = variableICProporcion, level.factor = variableLevelICProporcion,n.exitos=valornexitos,n.fracasos=valornfracasos, nivel.confianza=valornConfianza)

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "Cprop.test", reset="contrasteHipotesisDiferenciaProporciones", apply="contrasteHipotesisDiferenciaProporciones")
  tkgrid(comboBoxFrame,sticky="nw")
  tkgrid(comboBoxFrame2,sticky="nw")
  tkgrid(selectFactorsFrame,labelRcmdr(seleccionFrame, text="          "),muestrasFrame,sticky="nw")
  tkgrid(seleccionFrame, sticky="nw")
  tkgrid(labelRcmdr(top, text="          "))
  ###
  tkgrid(labelRcmdr(rightFrame, text="        "),sticky="nw")
  tkgrid(diferenciaProporcionesFrame,sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")
  tkgrid(alternativeFrame,labelRcmdr(optionsFrame, text="          "),rightFrame, sticky="nw")
  tkgrid(optionsFrame,sticky="nw")
  ###

  tkgrid(buttonsFrame, sticky="w")


  dialogSuffix()
}





