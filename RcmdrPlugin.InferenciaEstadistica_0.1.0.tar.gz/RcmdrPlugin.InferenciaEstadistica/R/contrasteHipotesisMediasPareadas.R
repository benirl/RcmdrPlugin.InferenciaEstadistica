contrasteHipotesisMediasPareadas <- function () {
 invisible(library(tcltk2))

  defaults <- list (initial.var1=gettextRcmdr("<no variable selected>"), initial.var2=gettextRcmdr("<no variable selected>"),initial.nconf="0.95",initial.alternative = "two.sided",initial.mu = "0.0")
  dialog.values <- getDialog ("contrasteHipotesisMediasPareadas", defaults)
  initializeDialog(title = gettextRcmdr("Contraste Hip�tesis para Medias Pareadas"))

  comboBoxFrame<-tkframe(top)

  selectVariable1ICMediasPareadas <- variableComboBox(comboBoxFrame, variableList=Numeric(),
     initialSelection=dialog.values$initial.var1, title=gettextRcmdr("Primera Variable (Elegir una)"))

  selectVariable2ICMediasPareadas <- variableComboBox(comboBoxFrame, variableList=Numeric(),
                                                      initialSelection=dialog.values$initial.var2, title=gettextRcmdr("Segunda Variable (Elegir una)"))




  optionsFrame <- tkframe(top)
  radioButtons(optionsFrame, name = "alternative", buttons = c("twosided",
                                                               "less", "greater"), values = c("two.sided", "less", "greater"),
               labels = gettextRcmdr(c("Diferencia Poblacional != mu0_1 - m0_2", "Diferencia Poblacional < mu0_1 - m0_2",
                                       "Diferencia Poblacional > mu0_1 - m0_2")), title = gettextRcmdr("Alternative Hypothesis"),
               initialValue = dialog.values$initial.alternative)


  rightFrame<-tkframe(top)

  muFrame <- tkframe(rightFrame)
  muVariable <- tclVar(dialog.values$initial.mu)
  muField <- ttkentry(muFrame, width = "5", textvariable = muVariable)
  tkgrid(labelRcmdr(muFrame, text="Hip�tesis Nula: mu0_1 - m0_2 = ", foreground="blue" ), muField, sticky="nw")

  nConfianzaFrame<-tkframe(rightFrame)
  nConfianzaVar<-tclVar(dialog.values$initial.nconf)
  nConfianzaEntry<-ttkentry(nConfianzaFrame,width="5",textvariable=nConfianzaVar)
#  tkgrid(labelRcmdr(nConfianzaFrame, text="Nivel de Confianza (1-alpha)= ", foreground="blue" ),nConfianzaEntry, sticky="nw")



  onOK <- function(){

    var1ICMedia<-getSelection(selectVariable1ICMediasPareadas)
    var2ICMedia<-getSelection(selectVariable2ICMediasPareadas)

    if(var1ICMedia=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesisMediasPareadas, message=gettextRcmdr("No seleccionada ninguna variable en Primera Variable"))
      return()}
    if(var2ICMedia=="<ninguna variable seleccionada>"){errorCondition(recall=contrasteHipotesisMediasPareadas, message=gettextRcmdr("No seleccionada ninguna variable en Segunda Variable"))
      return()}

     if(var1ICMedia==var2ICMedia){errorCondition(recall=contrasteHipotesisMediasPareadas, message=gettextRcmdr("Las variables seleccionadas no pueden ser iguales"))
      return()}

    valornConfianza<-tclvalue(nConfianzaVar)

    if(is.na(as.numeric(valornConfianza)) || (as.numeric(valornConfianza)<0)||(as.numeric(valornConfianza)>1)) {
      valornConfianza=0.95
      errorCondition(recall=contrasteHipotesisMediasPareadas, message=gettextRcmdr("Valor no v�lido para nivel de confianza, n�mero entre 0 y 1"))
      return()
    }
    else{valornConfianza<-as.numeric(valornConfianza)}

    valormu0<-tclvalue(muVariable)

    if(is.na(as.numeric(valormu0))){
      valormu0="0.0"
      errorCondition(recall=contrasteHipotesisMediasPareadas, message=gettextRcmdr("Valor no valido para la Hip?tesis Nula mu0"))
      return()
    }
    else{ valormu0<-as.numeric(valormu0)}

    varHAlternativa<-tclvalue(alternativeVariable)


    putDialog ("contrasteHipotesisMediasPareadas", list(initial.var1=var1ICMedia,initial.var2=var2ICMedia,initial.nconf=valornConfianza,
                                                        initial.alternative = varHAlternativa,initial.mu = valormu0))
    closeDialog()


###################### Imprimir la funci?n a llamar por RCommander ###########################################

   .activeDataSet<-ActiveDataSet()

    vICMedia1<-paste(.activeDataSet,"$",var1ICMedia, sep="")
    vICMedia2<-paste(.activeDataSet,"$",var2ICMedia, sep="")

    Haltern<-paste('"',varHAlternativa,'"',sep="")


    command2<- paste("aux<-t.test(",vICMedia1,", ",vICMedia2,", mu=",valormu0,", alternative=",Haltern,", paired = TRUE, conf.level=",valornConfianza,")",sep="")

    tipointervalo<-"\\nCONTRASTE DE HIPOTESIS PARA LA DIFERENCIA DE MEDIAS PAREADAS\\n"
    linaux<-paste(rep(c("-"," "),(nchar(tipointervalo)/2)),collapse="")
    tipointervalo<-paste(tipointervalo, linaux,sep="")
    command2<- paste("local({\n",command2,"\n",sep="")

    resultado<-paste('cat("',tipointervalo, "\\nVariables: ", var1ICMedia," vs. ",var2ICMedia, "\\n",'")', sep="" )
    distribucion<-'\n cat("Distribuci�n:",names(aux$statistic),"con",as.numeric(aux$parameter),"grados de libertad\\n")'
    e.contraste<- '\n cat("Estad�stico contraste:",as.numeric(aux$statistic),"\\n")'
    p.valor<-'\n if(aux$p.value>0.05){cat("P.valor:",aux$p.value,"\\n")}
    if(aux$p.value>=0.025 && aux$p.value<=0.05){cat("P.valor:",aux$p.value,"*\\n")}
    if(aux$p.value>=0.0001 && aux$p.value<=0.025){cat("P.valor:",aux$p.value,"**\\n")}
    if(aux$p.value>=0 && aux$p.value<=0.0001){cat("P.valor:",aux$p.value,"***\\n")}\n'

    if (varHAlternativa == "two.sided"){h.alt<-paste("Diferencia poblacional no es igual a Hip�tesis Nula = ",valormu0,sep="")}
    if (varHAlternativa == "less"){h.alt<-paste("Diferencia poblacional es menor a Hip�tesis Nula = ",valormu0,sep="")}
    if (varHAlternativa == "greater"){h.alt<- paste("Diferencia poblacional es mayor a Hip�tesis Nula = ",valormu0,sep="")}
    h.alt<-paste('\n cat("Hip�tesis Alternativa:","',h.alt,'","\\n")')

    e.muestral<-'\n cat("Estimador Muestral:",names(aux$estimate),as.numeric(aux$estimate),"\\n")'
    command2<- paste(command2, resultado, distribucion,e.contraste,p.valor, h.alt,e.muestral,"\n})",sep="" )

    doItAndPrint(command2)


###############################################################################################################

    ##calcular_HCMediasPareadas(v.numerica=variableICMedia,varianza.conocida=varConocida,valor.varianza=valorvarianza, nivel.confianza=valornConfianza)

   tkfocus(CommanderWindow())
  }

  OKCancelHelp(helpSubject = "t.test", reset="contrasteHipotesisMediasPareadas", apply="contrasteHipotesisMediasPareadas")

  tkgrid(getFrame(selectVariable1ICMediasPareadas),labelRcmdr(comboBoxFrame, text="          "),getFrame(selectVariable2ICMediasPareadas), sticky="nw")
  tkgrid(comboBoxFrame, sticky="nw")
  tkgrid(labelRcmdr(top, text="          "), sticky="nw")

  tkgrid(labelRcmdr(rightFrame, text="        "),sticky="nw")
  tkgrid(muFrame,sticky="nw")
  tkgrid(nConfianzaFrame, sticky="nw")
  tkgrid(alternativeFrame,labelRcmdr(optionsFrame, text="          "),rightFrame, sticky="nw")
  tkgrid(optionsFrame,sticky="nw")

  tkgrid(buttonsFrame, sticky="w")

  dialogSuffix()
}


