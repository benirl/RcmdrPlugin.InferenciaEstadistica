resumenDatosTabulados <- function(){
  Library("abind")
  Library("e1071")
  defaults <- list(initial.li=gettextRcmdr("<no variable selected>"),initial.ls=gettextRcmdr("<no variable selected>"),
                   initial.fr=gettextRcmdr("<no variable selected>"), initial.tablafrecuencia="0",
                   initial.mean="1",
                   initial.sd="1", initial.se.mean="0", initial.IQR="1",initial.mode="0", initial.cv="0",
                   initial.quantiles.variable="1",
                   initial.quantiles="0, .25, .5, .75, 1",
                   initial.skewness="0", initial.kurtosis="0", initial.tab=0)

  activeDataSet <- ActiveDataSet()
  dialog.values <- getDialog("resumenDatosTabulados", defaults)
  initial.group <- dialog.values$initial.group
  initializeDialog(title=gettextRcmdr("Resumen N�merico Datos Tabulados"), use.tabs=TRUE, tabs=c("dataTab", "statisticsTab"))

 limiteInferiorBox <- variableComboBox(dataTab, variableList=Numeric(),
                            initialSelection=dialog.values$initial.li, title=gettextRcmdr("L�mite Inferior"))


 limiteSuperiorBox<- variableComboBox(dataTab, variableList=Numeric(),
                                                initialSelection=dialog.values$initial.ls, title=gettextRcmdr("L�mite Superior"))

 frecuenciaBox <- variableComboBox(dataTab, variableList=Numeric(),
                                          initialSelection=dialog.values$initial.fr, title=gettextRcmdr("Frecuencia"))

 stkFrame<-tkframe(dataTab)
 tablafrecuenciaVar<-tclVar(dialog.values$initial.tablafrecuencia)
 tablafrecuenciaCheckBox<-ttkcheckbutton(stkFrame, variable=tablafrecuenciaVar,text=gettextRcmdr("Tabla Frecuencias"))


  checkBoxes(window = statisticsTab, frame="checkBoxFrame", boxes=c("mean", "sd", "se.mean", "IQR","mode", "cv","skewness", "kurtosis"),
             initialValues=c(dialog.values$initial.mean, dialog.values$initial.sd, dialog.values$initial.se.mean, dialog.values$initial.IQR,dialog.values$initial.mode, dialog.values$initial.cv,dialog.values$initial.skewness, dialog.values$initial.kurtosis),
             labels=gettextRcmdr(c("Mean", "Standard Deviation", "Standard Error of Mean", "Interquartile Range","Moda", "Coefficient of Variation","Skewness", "Kurtosis")))

  quantilesVariable <- tclVar(dialog.values$initial.quantiles.variable)
  quantilesFrame <- tkframe(statisticsTab)
  quantilesCheckBox <- tkcheckbutton(quantilesFrame, variable=quantilesVariable,
                                     text=gettextRcmdr("Quantiles:"))
  quantiles <- tclVar(dialog.values$initial.quantiles)
  quantilesEntry <- ttkentry(quantilesFrame, width="20", textvariable=quantiles)


  onOK <- function(){
    tab <- if (as.character(tkselect(notebook)) == dataTab$ID) 0 else 1
    linfvar<- getSelection(limiteInferiorBox)
    lsupvar<-getSelection(limiteSuperiorBox)
    frevar<- getSelection(frecuenciaBox )
    tfrec<-tclvalue(tablafrecuenciaVar)

    quants <- tclvalue(quantiles)
    meanVar <- tclvalue(meanVariable)
    sdVar <- tclvalue(sdVariable)
    se.meanVar <- tclvalue(se.meanVariable)
    IQRVar <- tclvalue(IQRVariable)
    modeVar <- tclvalue(modeVariable)
    cvVar <- tclvalue(cvVariable)
    quantsVar <- tclvalue(quantilesVariable)
    skewnessVar <- tclvalue(skewnessVariable)
    kurtosisVar <- tclvalue(kurtosisVariable)

    putDialog("resumenDatosTabulados", list(
      initial.li=linfvar,initial.ls=lsupvar,initial.fr=frevar,initial.tablafrecuencia=tfrec, initial.mean=meanVar, initial.sd=sdVar, initial.se.mean=se.meanVar, initial.IQR=IQRVar,initial.mode=modeVar, initial.cv=cvVar,
      initial.quantiles.variable=quantsVar, initial.quantiles=quants,
      initial.skewness=skewnessVar, initial.kurtosis=kurtosisVar, initial.tab=tab
    ))


    activeDataSet <- ActiveDataSet()
    activeDataSet<-get(activeDataSet)

     if(linfvar=="<ninguna variable seleccionada>"){errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("No seleccionada variable L?mite Inferior"))
      return()}
    else{variableLimiteInferior<-activeDataSet[,linfvar]}

    if(lsupvar=="<ninguna variable seleccionada>"){errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("No seleccionada variable L?mite Superior"))
      return()}
    else{variableLimiteSuperior<-activeDataSet[,lsupvar]}

    if(frevar=="<ninguna variable seleccionada>"){errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("No seleccionada variable Frecuencia"))
      return()}
    else{variableFrecuencia<-activeDataSet[,frevar]}

    ##Distintas verificacaciones de Limite Inferior y Limite Superior - para comprobar que son variables de Datos Tabulados

    ##Comprobamos que limite inferior y limite superior est?n ordenados

    if(prod(variableLimiteInferior==sort(variableLimiteInferior))!=TRUE){errorCondition(recall=resumenDatosTabulados,
     message=gettextRcmdr("Datos Variable L�mite Inferior no est�n ordenados"))
    return()}

    if(prod(variableLimiteSuperior==sort(variableLimiteSuperior))!=TRUE){errorCondition(recall=resumenDatosTabulados,
    message=gettextRcmdr("Datos Variable L�mite Superior no est?n ordenados"))
      return()}

    if(prod(variableLimiteInferior<=variableLimiteSuperior)!=TRUE){errorCondition(recall=resumenDatosTabulados,
      message=gettextRcmdr("Datos Variable L�mite Inferior mayores que Variable L�mite Superior"))
      return()}
    if(prod(variableLimiteSuperior[-length(variableLimiteSuperior)]<=variableLimiteInferior[-1])!=TRUE){ errorCondition(recall=resumenDatosTabulados,
    message=gettextRcmdr("Datos variable L�mite inferior y l�mite superior no se corresponden con datos tabulados Li[x]>=Ls[x-1]"))
    return()}

    closeDialog()

    quants <- as.numeric( strsplit(quants,split=",")[[1]])

    posiblesstatistic<-c("mean", "sd", "se(mean)", "IQR","mode", "quantiles", "cv", "skewness", "kurtosis")
    statselegidas<-c(meanVar, sdVar, se.meanVar, IQRVar, modeVar, quantsVar, cvVar, skewnessVar, kurtosisVar)

    stats <- posiblesstatistic[as.logical(as.numeric(statselegidas))]

    if (length(stats) == 0){
      errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("Debe seleccionar al menos un est�distico"))
      return()
    }

    if((NA %in% quants)||(length( quants[(quants<0)|(quants>1)])!=0)){
      errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("Los cuantiles P deben ser un n�mero positivo entre 0 y 1"))
      return()
    }

    if((length(quants)==0)&&(quantsVar==1)){
      errorCondition(recall=resumenDatosTabulados, message=gettextRcmdr("Si se selecciona la estad�stica quantil el valor del mismo no puede ser nulo"))
      return()
    }




##################### Imprimir la funci?n a llamar por RCommander ###########################################

    .activeDataSet<-ActiveDataSet()

    if(linfvar=="<ninguna variable seleccionada>"){vLinf<-"NULL"}
    else{vLinf<-paste(.activeDataSet,"$",linfvar, sep="")}

    if(lsupvar=="<ninguna variable seleccionada>"){vLsup<-"NULL"}
    else{vLsup<-paste(.activeDataSet,"$",lsupvar, sep="")}

    if(frevar=="<ninguna variable seleccionada>"){vFrec<-"NULL"}
    else{vFrec<-paste(.activeDataSet,"$",frevar, sep="")}

    stadisticas <- paste("c(",
                         paste(c('"mean"', '"sd"', '"se(mean)"', '"IQR"','"mode"', '"quantiles"', '"cv"', '"skewness"', '"kurtosis"')
                               [c(meanVar, sdVar, se.meanVar, IQRVar,modeVar, quantsVar, cvVar, skewnessVar, kurtosisVar) == 1],
                               collapse=", "), ")", sep="")



    if(0 == length(quants)) cuantiles <-"NULL"
    else{
      cuantiles <- if (length(quants) == 1) paste(quants , sep="")
      else paste("c(", paste(quants, collapse=",", sep=""), ")", sep="")
    }

    print_tabla_Frecuencia<-as.logical(as.numeric(tfrec))

    command<- paste("calcularResumenDatosTabulados(l_inf=", vLinf,", l_sup=",vLsup,", ni=",vFrec ,", statistics =", stadisticas,", quantiles = ",cuantiles,", tablaFrecuencia=",print_tabla_Frecuencia,")",sep="" )
    print(command)
    doItAndPrint(command)

    tkfocus(CommanderWindow())
  }
  OKCancelHelp(helpSubject="calcularResumenDatosTabulados", reset="resumenDatosTabulados", apply ="resumenDatosTabulados")


 tkgrid(getFrame(limiteInferiorBox),sticky="nw")
  tkgrid(getFrame(limiteSuperiorBox),sticky="nw")
  tkgrid(getFrame(frecuenciaBox),sticky="nw")
  tkgrid(labelRcmdr(dataTab, text="     "),sticky="nw")
  tkgrid(tablafrecuenciaCheckBox, sticky="w")
  tkgrid(stkFrame, sticky="nw")


  tkgrid(checkBoxFrame, sticky="nw")
  tkgrid(quantilesCheckBox, quantilesEntry, sticky="w")
  tkgrid(quantilesFrame)

  dialogSuffix(use.tabs=TRUE, grid.buttons=TRUE, tabs=c("dataTab", "statisticsTab"),
               tab.names=c("Data", "Statistics"))
}


